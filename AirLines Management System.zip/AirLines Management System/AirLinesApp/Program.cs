﻿using AirLinesLibrary;
using AirLinesLibrary.Models;
using AirLinesLibrary.Repos;
using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace AirLinesApp;

public class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("--- EY AirLines Management System ---");
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("1. Manage Flight");
            Console.WriteLine("2. Manage Flight Schedule");
            Console.WriteLine("3. Manage Flight Reservation");
            Console.WriteLine("4. Manage Flight Reservation Details");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("-------------------------");
            switch (choice)
            {
                case 1: ManageFlight(); 
                    break;
                case 2: ManageFlightSchedule();
                    break;
                case 3: ManageFlightReservation();
                    break;
                case 4:
                    ManageFlightReservationDetails();
                    break;
                case 5: return;
                default: Console.WriteLine("Invalid Choice:"); 
                    break;
            }

        }
    }

    private static void ManageFlightReservation()
    {
        while (true)
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("--- Manage Flight Reservation ---");
            Console.WriteLine("-------------------------");
            Console.WriteLine("1. New Flight Reservation");
            Console.WriteLine("2. View All Flight Reservations");
            Console.WriteLine("3. View Flight Reservations by PNR");
            Console.WriteLine("4. View Flight Reservations by Flight Number and Date");
            Console.WriteLine("5. Update Flight Reservation");
            Console.WriteLine("6. Delete Flight Reservation");
            Console.WriteLine("7. Exit");
            Console.WriteLine("-------------------------");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("-------------------------");

            switch (choice)
            {
                case 1:
                    NewFlightReservation();
                    break;
                case 2:
                    ViewAllFlightReservations();
                    break;
                case 3:
                    ViewFlightReservationByPnr();
                    break;
                case 4:
                    ViewFlightReservationBySchedule();
                    break;
                case 5:
                    UpdateFlightReservation();
                    break;
                case 6:
                    DeleteFlightReservation();
                    break;
                case 7: return;
                default:
                    Console.WriteLine("Invalid Choice:");
                    break;
            }
        }
        static void NewFlightReservation()
        {
            ReservationMaster master = new ReservationMaster();
            ADOReservationMasterRepository masterepo = new ADOReservationMasterRepository();

            Console.Write("Enter PNR:");
            master.PNR = Console.ReadLine();
            Console.Write("Enter Flight Number:");
            master.FlightNo = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            master.FlightDate = fdate;
            masterepo.InsertMaster(master);
        }

        static void ViewAllFlightReservations()
        {

            ADOReservationMasterRepository masterrepo = new ADOReservationMasterRepository();
            List<ReservationMaster> list = masterrepo.GetAllMaster();
            foreach (ReservationMaster master in list)
            {
                Console.WriteLine($"Flight PNR:{master.PNR}");
                Console.WriteLine($"Flight Number:{master.FlightNo}");
                Console.WriteLine($"Flight Date:{master.FlightDate}");
                Console.WriteLine("-------------------------");
            }
        }
        static void ViewFlightReservationByPnr()
        {
            Console.Write("Enter PNR to View:");
            string pnr = Console.ReadLine();
            ADOReservationMasterRepository masterrepo = new ADOReservationMasterRepository();

            try
            {
                ReservationMaster master = masterrepo.GetMaster(pnr);
                Console.WriteLine($"Flight PNR:{master.PNR}");
                Console.WriteLine($"Flight Number:{master.FlightNo}");
                Console.WriteLine($"Flight Date:{master.FlightDate}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void ViewFlightReservationBySchedule()
        {
            Console.Write("Enter Flight Number:");
            string fno = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Hour:");
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            ADOReservationMasterRepository masterrepo = new ADOReservationMasterRepository();
            try
            {
                List<ReservationMaster> masters = masterrepo.GetMasterBySchedule(fno, fdate);
                foreach (ReservationMaster master in masters)
                {
                    Console.WriteLine($"Flight PNR:{master.PNR}");
                    Console.WriteLine($"Flight Number:{master.FlightNo}");
                    Console.WriteLine($"Flight Date:{master.FlightDate}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        static void UpdateFlightReservation()
        {
            Console.Write("Enter PNR to Update:");
            string pnr = Console.ReadLine();
            ReservationMaster master = new ReservationMaster();
            Console.Write("Enter Flight Number");
            master.FlightNo = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            master.FlightDate = fdate;
            ADOReservationMasterRepository masterepo = new ADOReservationMasterRepository();
            masterepo.UpdateMaster(pnr, master);
            Console.WriteLine("Reservations Updated");
        }
        static void DeleteFlightReservation()
        {
            Console.Write("Enter PNR to Delete:");
            string pnr = Console.ReadLine();
            ADOReservationMasterRepository masterepo = new ADOReservationMasterRepository();
            masterepo.DeleteMaster(pnr);
            Console.WriteLine("Reservations Deleted");
        }
    }

    private static void ManageFlightSchedule()
    {
        while (true)
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("--- Manage Flight Schedule ---");
            Console.WriteLine("-------------------------");
            Console.WriteLine("1. Add New Flight Schedule");
            Console.WriteLine("2. View All Flight Schedules");
            Console.WriteLine("3. View Flight Schedule by Flight Number and Date");
            Console.WriteLine("4. View Flight Schedules by Flight Number");
            Console.WriteLine("5. View Flight Schedules by Date");
            Console.WriteLine("6. Update Flight Schedule");
            Console.WriteLine("7. Delete Flight Schedule");
            Console.WriteLine("8. Exit");
            Console.WriteLine("-------------------------");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    AddFlightSchedule();
                    break;
                case 2:
                    ViewAllFlightSchedules();
                    break;
                case 3:
                    ViewFlightSchedule();
                    break;
                case 4:
                    ViewFlightScheduleByFno();
                    break;
                case 5:
                    ViewFlightScheduleByDate();
                    break;
                case 6:
                    UpdateFlightSchedule();
                    break;
                case 7:
                    DeleteFlightSchedule();
                    break;
                case 8: return;
                default:
                    Console.WriteLine("Invalid Choice:");
                    break;
            }
        }

        static void DeleteFlightSchedule()
        {
            Console.Write("Enter Flight Number:");
            string fno = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();
            schedulerepo.DeleteSchedule(fno, fdate);
            Console.WriteLine("Flight Schedules Deleted");
        }

        static void UpdateFlightSchedule()
        {
            Console.Write("Enter Flight Number:");
            string fno = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();
            FlightSchedule fs = new FlightSchedule();
            Console.WriteLine("Enter the New Departure Details");
            Console.Write("Enter Year(YYYY):");
            int year2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Hour:");
            int hr2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Minutes:");
            int min2 = Convert.ToInt32(Console.ReadLine());
            DateTime fdt2 = new DateTime(year2, mon2, day2, hr2, min2, 00);
            fs.DepartTime = fdt;
            Console.WriteLine("Enter the Arrival Details");
            Console.Write("Enter Year(YYYY):");
            int year3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Hour:");
            int hr3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Minutes:");
            int min3 = Convert.ToInt32(Console.ReadLine());
            DateTime fdt3 = new DateTime(year3, mon3, day3, hr3, min3, 00);
            schedulerepo.UpdateSchedule(fno, fdate, fs);
            Console.WriteLine("Flight Schedules Updated");

        }

        static void ViewFlightScheduleByDate()
        {
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();

            try
            {
                List<FlightSchedule> flightSchedules = schedulerepo.GetSchedulesByDate(fdate);
                foreach (FlightSchedule schedule in flightSchedules)
                {
                    Console.WriteLine($"Flight Number: {schedule.FlightNo}");
                    Console.WriteLine($"Departure Date: {schedule.FlightDate}");
                    TimeOnly departTime = TimeOnly.FromDateTime(schedule.DepartTime);
                    Console.WriteLine($"Departure Time: {departTime}");
                    TimeOnly arriveTime = TimeOnly.FromDateTime(schedule.ArriveTime);
                    Console.WriteLine($"Arrival Time: {arriveTime}");
                    Console.WriteLine("-------------------------");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ViewFlightScheduleByFno()
        {
            Console.Write("Enter Flight Number:");
            string fno = Console.ReadLine();
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();

            try
            {
                List<FlightSchedule> flightSchedules = schedulerepo.GetSchedulesByFlight(fno);
                foreach (FlightSchedule schedule in flightSchedules)
                {
                    Console.WriteLine($"Flight Number: {schedule.FlightNo}");
                    Console.WriteLine($"Departure Date: {schedule.FlightDate}");
                    TimeOnly departTime = TimeOnly.FromDateTime(schedule.DepartTime);
                    Console.WriteLine($"Departure Time: {departTime}");
                    TimeOnly arriveTime = TimeOnly.FromDateTime(schedule.ArriveTime);
                    Console.WriteLine($"Arrival Time: {arriveTime}");
                    Console.WriteLine("-------------------------");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ViewFlightSchedule()
        {
            Console.Write("Enter Flight Number:");
            string fno = Console.ReadLine();
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day);
            DateOnly fdate = DateOnly.FromDateTime(fdt);

            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();
            try
            {
                FlightSchedule fs = schedulerepo.GetSchedule(fno, fdate);
                Console.WriteLine($"Flight Number: {fs.FlightNo}");
                Console.WriteLine($"Departure Date: {fs.FlightDate}");
                TimeOnly departTime = TimeOnly.FromDateTime(fs.DepartTime);
                Console.WriteLine($"Departure Time: {departTime}");
                TimeOnly arriveTime = TimeOnly.FromDateTime(fs.ArriveTime);
                Console.WriteLine($"Arrival Time: {arriveTime}");
                Console.WriteLine("-------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ViewAllFlightSchedules()
        {
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();
            List<FlightSchedule> flightSchedules = schedulerepo.GetAllSchedules();
            foreach (FlightSchedule fs in flightSchedules)
            {
                Console.WriteLine($"Flight Number: {fs.FlightNo}");
                Console.WriteLine($"Departure Date: {fs.FlightDate}");
                TimeOnly departTime = TimeOnly.FromDateTime(fs.DepartTime);
                Console.WriteLine($"Departure Time: {departTime}");
                TimeOnly arriveTime = TimeOnly.FromDateTime(fs.ArriveTime);
                Console.WriteLine($"Arrival Time: {arriveTime}");
                Console.WriteLine("-------------------------");
            }
        }

        static void AddFlightSchedule()
        {
            FlightSchedule fs = new FlightSchedule();
            Console.Write("Enter Flight Number:");
            fs.FlightNo = Console.ReadLine();
            Console.WriteLine("Enter the Departure Details");
            Console.Write("Enter Year(YYYY):");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Hour:");
            int hr = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Minutes:");
            int min = Convert.ToInt32(Console.ReadLine());
            DateTime fdt = new DateTime(year, mon, day, hr, min, 00);
            DateOnly fdate = DateOnly.FromDateTime(fdt);
            fs.FlightDate = fdate;
            fs.DepartTime = fdt;
            Console.WriteLine("Enter the Arrival Details");
            Console.Write("Enter Year(YYYY):");
            int year2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Month(MM):");
            int mon2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Day(DD):");
            int day2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Hour:");
            int hr2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Minutes:");
            int min2 = Convert.ToInt32(Console.ReadLine());
            DateTime fdt2 = new DateTime(year2, mon2, day2, hr2, min2, 00);
            fs.ArriveTime = fdt2;
            ADOFlightScheduleRepository schedulerepo = new ADOFlightScheduleRepository();
            schedulerepo.InsertSchedule(fs);
            Console.WriteLine("Flight Schedules Inserted");
        }
    }

    private static void ManageFlight()
    {
        while (true)
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("--- Manage Flight ---");
            Console.WriteLine("-------------------------");
            Console.WriteLine("1. Add New Flight");
            Console.WriteLine("2. View All Flights");
            Console.WriteLine("3. View Flight");
            Console.WriteLine("4. Update Flight");
            Console.WriteLine("5. Delete Flight");
            Console.WriteLine("6. Exit");
            Console.WriteLine("-------------------------");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("-------------------------");

            switch (choice)
            {
                case 1:
                    AddFlight();
                    break;
                case 2:
                    ViewAllFlight();
                    break;
                case 3:
                    ViewFlight();
                    break;
                case 4:
                    UpdateFlight();
                    break;
                case 5:
                    DeleteFlight();
                    break;
                case 6: return;
                default:
                    Console.WriteLine("Invalid Choice:");
                    break;
            }
        }
        static void DeleteFlight()
        {
            Console.Write("Enter Flight Number to Delete:");
            string fno = Console.ReadLine();
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            flightrepo.DeleteFlight(fno);
            Console.WriteLine("Flight Details Deleted");
        }

        static void UpdateFlight()
        {
            Console.Write("Enter Flight Number to Update: ");
            string fno = Console.ReadLine();
            Flight flight = new Flight();
            Console.Write("Enter New Departure City:");
            flight.FromCity = Console.ReadLine();
            Console.Write("Enter New destination City:");
            flight.ToCity = Console.ReadLine();
            Console.Write("Enter new Total Number of Seats:");
            flight.TotalSeats = Convert.ToInt32(Console.ReadLine());
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            flightrepo.UpdateFlight(fno, flight);
            Console.WriteLine("Flight Details Updated");
        }

        static void ViewFlight()
        {
            Console.Write("Enter Flight Number to View: ");
            string fno = Console.ReadLine();
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            try
            {
                Flight flight = flightrepo.GetFlight(fno);
                Console.WriteLine($"Flight Number is {flight.FlightNo}");
                Console.WriteLine($"Departs From {flight.FromCity}");
                Console.WriteLine($"Goes To {flight.ToCity}");
                Console.WriteLine($"Total Seats are {flight.TotalSeats}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ViewAllFlight()
        {
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            List<Flight> flights = flightrepo.GetAllFlights();
            foreach (Flight flight in flights)
            {
                Console.WriteLine($"Flight Number is {flight.FlightNo}");
                Console.WriteLine($"Departs From {flight.FromCity}");
                Console.WriteLine($"Goes To {flight.ToCity}");
                Console.WriteLine($"Total Seats are {flight.TotalSeats}");
                Console.WriteLine("-------------------------");
            }

        }

        static void AddFlight()
        {
            Flight flight = new Flight();
            Console.Write("Enter Flight Number:");
            flight.FlightNo = Console.ReadLine();
            Console.Write("Departs From:");
            flight.FromCity = Console.ReadLine();
            Console.Write("Goes To:");
            flight.ToCity = Console.ReadLine();
            Console.Write("Enter Total Number of Seats:");
            flight.TotalSeats = Convert.ToInt32(Console.ReadLine());
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            flightrepo.InsertFlight(flight);
            Console.WriteLine("Flight Details Added");
        }
    }

    private static void ManageFlightReservationDetails()
    {
        while (true)
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("--- Manage Flight Reservation Details ---");
            Console.WriteLine("-------------------------");
            Console.WriteLine("1. Insert Flight Reservation Details");
            Console.WriteLine("2. View All Flight Reservation Details");
            Console.WriteLine("3. View Flight Reservation Details by PNR");
            Console.WriteLine("4. View Flight Reservation Detail");
            Console.WriteLine("5. Update Flight Reservation Details");
            Console.WriteLine("6. Delete Flight Reservation Details");
            Console.WriteLine("7. Exit");
            Console.WriteLine("-------------------------");
            Console.Write("Enter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("-------------------------");

            switch (choice)
            {
                case 1:
                    InsertReservationDetails();
                    break;
                case 2:
                    ViewAllReservationDetails();
                    break;
                case 3:
                    ViewReservationDetailsByPnr();
                    break;
                case 4:
                    ViewReservationDetail();
                    break;
                case 5:
                    UpdateReservationDetail();
                    break;
                case 6:
                    DeleteReservationDetail();
                    break;
                case 7: return;
                default:
                    Console.WriteLine("Invalid Choice:");
                    break;
            }
        }
        static void InsertReservationDetails()
        {
            ReservationDetail detail = new ReservationDetail();
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            Console.Write("Enter PNR:");
            detail.PNR = Console.ReadLine();
            Console.Write("Enter Passenger Number:");
            detail.PassengerNo = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Passenger Name:");
            detail.PassengerName = Console.ReadLine();
            Console.Write("Enter Passenger Gender[O/F/M]:");
            detail.Gender = Console.ReadLine();
            detailrepo.InsertDetail(detail);
            Console.WriteLine("Reservation Details Inserted");
                        
        }
        static void ViewAllReservationDetails()
        {
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            List<ReservationDetail> details = detailrepo.GetAllDetails();
            foreach (ReservationDetail detail in details)
            {
                Console.WriteLine($"PNR is {detail.PNR}");
                Console.WriteLine($"Passenger Number: {detail.PassengerNo}");
                Console.WriteLine($"Passenger Name: {detail.PassengerName}");
                Console.WriteLine($"Passenger Gender: {detail.Gender}");
                Console.WriteLine("-------------------------");
            }
        }
        static void ViewReservationDetailsByPnr()
        {
            Console.Write("Enter PNR to View:");
            string pnr = Console.ReadLine();
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            try
            {
                List<ReservationDetail> details = detailrepo.GetDetailsByPNR(pnr);
                foreach (ReservationDetail detail in details)
                {
                    Console.WriteLine($"PNR is {detail.PNR}");
                    Console.WriteLine($"Passenger Number: {detail.PassengerNo}");
                    Console.WriteLine($"Passenger Name: {detail.PassengerName}");
                    Console.WriteLine($"Passenger Gender: {detail.Gender}");
                    Console.WriteLine("-------------------------");
                }

            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void ViewReservationDetail()
        {
            Console.Write("Enter PNR to View:");
            string pnr = Console.ReadLine();
            Console.Write("Enter Passenger Number:");
            int pno = Convert.ToInt32(Console.ReadLine());
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            try
            {
                ReservationDetail detail = detailrepo.GetDetail(pnr,pno);
                Console.WriteLine("-------------------------");
                Console.WriteLine($"PNR is {detail.PNR}");
                Console.WriteLine($"Passenger Number: {detail.PassengerNo}");
                Console.WriteLine($"Passenger Name: {detail.PassengerName}");
                Console.WriteLine($"Passenger Gender: {detail.Gender}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void DeleteReservationDetail()
        {
            Console.Write("Enter PNR to View:");
            string pnr = Console.ReadLine();
            Console.Write("Enter Passenger Number:");
            int pno = Convert.ToInt32(Console.ReadLine());
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            detailrepo.DeleteDetail(pnr, pno);
        }
        static void UpdateReservationDetail()
        {
            Console.Write("Enter PNR to Update:");
            string pnr = Console.ReadLine();
            Console.Write("Enter Passenger Number to Update:");
            int pno = Convert.ToInt32(Console.ReadLine());
            ADOReservationDetailRepository detailrepo = new ADOReservationDetailRepository();
            ReservationDetail detail = new ReservationDetail();
            Console.Write("Enter Passenger Name:");
            detail.PassengerName = Console.ReadLine();
            Console.Write("Enter Passenger Gender[O/F/M]:");
            detail.Gender = Console.ReadLine();
            detailrepo.UpdateDetail(pnr, pno, detail);
            Console.WriteLine("Reservation Details Updated");
        }
    }
    
}

