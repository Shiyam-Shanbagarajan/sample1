﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AirLinesLibrary;
using AirLinesLibrary.Repos;
using AirLinesLibrary.Models;

namespace AirLinesWinFormApp
{
    public partial class UpdateFlightForm : Form
    {
        public UpdateFlightForm()
        {
            InitializeComponent();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            try
            {
                string fno = txtfno.Text;
                ADOFlightRepository flightrepo = new ADOFlightRepository();
                Flight check = flightrepo.GetFlight(fno);
                Flight flight = new Flight();
                flight.FromCity = txtfrom.Text;
                flight.ToCity = txtto.Text;
                flight.TotalSeats = Convert.ToInt32(txttot.Text);
                flightrepo.UpdateFlight(fno, flight);
                MessageBox.Show("Flight Details Updated");
                txtfno.Text = "";
                txtfrom.Text = "";
                txtto.Text = "";
                txttot.Text = "";
            }
            catch (AirLineException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                string fno = txtfno.Text;
                ADOFlightRepository flightrepo = new ADOFlightRepository();
                Flight flight = flightrepo.GetFlight(fno);
                txtfrom.Text = flight.FromCity;
                txtto.Text = flight.ToCity;
                txttot.Text = Convert.ToString(flight.TotalSeats);

            }
            catch (AirLineException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
