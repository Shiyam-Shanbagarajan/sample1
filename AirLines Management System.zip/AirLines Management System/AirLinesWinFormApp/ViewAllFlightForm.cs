﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AirLinesLibrary;
using AirLinesLibrary.Repos;

namespace AirLinesWinFormApp
{
    public partial class ViewAllFlightForm : Form
    {
        public ViewAllFlightForm()
        {
            InitializeComponent();
        }

        private void ViewAllFlightForm_Load(object sender, EventArgs e)
        {
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            BindingSource bs = new BindingSource();
            bs.DataSource = flightrepo.GetAllFlights();
            flightGrid.DataSource = bs;
        }
    }
}
