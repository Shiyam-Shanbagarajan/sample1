﻿namespace AirLinesWinFormApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            eYAirLinesToolStripMenuItem = new ToolStripMenuItem();
            manageFlightsToolStripMenuItem = new ToolStripMenuItem();
            addFlightsToolStripMenuItem = new ToolStripMenuItem();
            viewFlightsToolStripMenuItem = new ToolStripMenuItem();
            updateFlightsToolStripMenuItem = new ToolStripMenuItem();
            deleteFlightsToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripSeparator();
            backToolStripMenuItem = new ToolStripMenuItem();
            manageFlightScheduleToolStripMenuItem = new ToolStripMenuItem();
            createScheduleToolStripMenuItem = new ToolStripMenuItem();
            viewScheduleToolStripMenuItem = new ToolStripMenuItem();
            updateScheduleToolStripMenuItem = new ToolStripMenuItem();
            deleteScheduleToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripSeparator();
            backToolStripMenuItem1 = new ToolStripMenuItem();
            manageReservationToolStripMenuItem = new ToolStripMenuItem();
            newReservationToolStripMenuItem = new ToolStripMenuItem();
            viewReservationsToolStripMenuItem = new ToolStripMenuItem();
            updateReservationToolStripMenuItem = new ToolStripMenuItem();
            deleteReservationToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem4 = new ToolStripSeparator();
            backToolStripMenuItem2 = new ToolStripMenuItem();
            manageReservationDetailsToolStripMenuItem = new ToolStripMenuItem();
            insertDetailsToolStripMenuItem = new ToolStripMenuItem();
            viewDetailsToolStripMenuItem = new ToolStripMenuItem();
            updateDetailsToolStripMenuItem = new ToolStripMenuItem();
            deleteDetailsToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { eYAirLinesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // eYAirLinesToolStripMenuItem
            // 
            eYAirLinesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { manageFlightsToolStripMenuItem, manageFlightScheduleToolStripMenuItem, manageReservationToolStripMenuItem, manageReservationDetailsToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            eYAirLinesToolStripMenuItem.Name = "eYAirLinesToolStripMenuItem";
            eYAirLinesToolStripMenuItem.Size = new Size(107, 29);
            eYAirLinesToolStripMenuItem.Text = "EYAirLines";
            // 
            // manageFlightsToolStripMenuItem
            // 
            manageFlightsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addFlightsToolStripMenuItem, viewFlightsToolStripMenuItem, updateFlightsToolStripMenuItem, deleteFlightsToolStripMenuItem, toolStripMenuItem2, backToolStripMenuItem });
            manageFlightsToolStripMenuItem.Name = "manageFlightsToolStripMenuItem";
            manageFlightsToolStripMenuItem.Size = new Size(332, 34);
            manageFlightsToolStripMenuItem.Text = "Manage Flights";
            // 
            // addFlightsToolStripMenuItem
            // 
            addFlightsToolStripMenuItem.Name = "addFlightsToolStripMenuItem";
            addFlightsToolStripMenuItem.Size = new Size(270, 34);
            addFlightsToolStripMenuItem.Text = "Add Flights";
            addFlightsToolStripMenuItem.Click += addFlightsToolStripMenuItem_Click;
            // 
            // viewFlightsToolStripMenuItem
            // 
            viewFlightsToolStripMenuItem.Name = "viewFlightsToolStripMenuItem";
            viewFlightsToolStripMenuItem.Size = new Size(270, 34);
            viewFlightsToolStripMenuItem.Text = "View All Flights";
            viewFlightsToolStripMenuItem.Click += viewFlightsToolStripMenuItem_Click;
            // 
            // updateFlightsToolStripMenuItem
            // 
            updateFlightsToolStripMenuItem.Name = "updateFlightsToolStripMenuItem";
            updateFlightsToolStripMenuItem.Size = new Size(270, 34);
            updateFlightsToolStripMenuItem.Text = "Update Flights";
            updateFlightsToolStripMenuItem.Click += updateFlightsToolStripMenuItem_Click;
            // 
            // deleteFlightsToolStripMenuItem
            // 
            deleteFlightsToolStripMenuItem.Name = "deleteFlightsToolStripMenuItem";
            deleteFlightsToolStripMenuItem.Size = new Size(270, 34);
            deleteFlightsToolStripMenuItem.Text = "Delete Flights";
            deleteFlightsToolStripMenuItem.Click += deleteFlightsToolStripMenuItem_Click;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(267, 6);
            // 
            // backToolStripMenuItem
            // 
            backToolStripMenuItem.Name = "backToolStripMenuItem";
            backToolStripMenuItem.Size = new Size(270, 34);
            backToolStripMenuItem.Text = "Back";
            // 
            // manageFlightScheduleToolStripMenuItem
            // 
            manageFlightScheduleToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { createScheduleToolStripMenuItem, viewScheduleToolStripMenuItem, updateScheduleToolStripMenuItem, deleteScheduleToolStripMenuItem, toolStripMenuItem3, backToolStripMenuItem1 });
            manageFlightScheduleToolStripMenuItem.Name = "manageFlightScheduleToolStripMenuItem";
            manageFlightScheduleToolStripMenuItem.Size = new Size(332, 34);
            manageFlightScheduleToolStripMenuItem.Text = "Manage Flight Schedule";
            // 
            // createScheduleToolStripMenuItem
            // 
            createScheduleToolStripMenuItem.Name = "createScheduleToolStripMenuItem";
            createScheduleToolStripMenuItem.Size = new Size(248, 34);
            createScheduleToolStripMenuItem.Text = "Create Schedule";
            // 
            // viewScheduleToolStripMenuItem
            // 
            viewScheduleToolStripMenuItem.Name = "viewScheduleToolStripMenuItem";
            viewScheduleToolStripMenuItem.Size = new Size(248, 34);
            viewScheduleToolStripMenuItem.Text = "View Schedule";
            // 
            // updateScheduleToolStripMenuItem
            // 
            updateScheduleToolStripMenuItem.Name = "updateScheduleToolStripMenuItem";
            updateScheduleToolStripMenuItem.Size = new Size(248, 34);
            updateScheduleToolStripMenuItem.Text = "Update Schedule";
            // 
            // deleteScheduleToolStripMenuItem
            // 
            deleteScheduleToolStripMenuItem.Name = "deleteScheduleToolStripMenuItem";
            deleteScheduleToolStripMenuItem.Size = new Size(248, 34);
            deleteScheduleToolStripMenuItem.Text = "Delete Schedule";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(245, 6);
            // 
            // backToolStripMenuItem1
            // 
            backToolStripMenuItem1.Name = "backToolStripMenuItem1";
            backToolStripMenuItem1.Size = new Size(248, 34);
            backToolStripMenuItem1.Text = "Back ";
            // 
            // manageReservationToolStripMenuItem
            // 
            manageReservationToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newReservationToolStripMenuItem, viewReservationsToolStripMenuItem, updateReservationToolStripMenuItem, deleteReservationToolStripMenuItem, toolStripMenuItem4, backToolStripMenuItem2 });
            manageReservationToolStripMenuItem.Name = "manageReservationToolStripMenuItem";
            manageReservationToolStripMenuItem.Size = new Size(332, 34);
            manageReservationToolStripMenuItem.Text = "Manage Reservation";
            // 
            // newReservationToolStripMenuItem
            // 
            newReservationToolStripMenuItem.Name = "newReservationToolStripMenuItem";
            newReservationToolStripMenuItem.Size = new Size(268, 34);
            newReservationToolStripMenuItem.Text = "New Reservation";
            // 
            // viewReservationsToolStripMenuItem
            // 
            viewReservationsToolStripMenuItem.Name = "viewReservationsToolStripMenuItem";
            viewReservationsToolStripMenuItem.Size = new Size(268, 34);
            viewReservationsToolStripMenuItem.Text = "View Reservations";
            // 
            // updateReservationToolStripMenuItem
            // 
            updateReservationToolStripMenuItem.Name = "updateReservationToolStripMenuItem";
            updateReservationToolStripMenuItem.Size = new Size(268, 34);
            updateReservationToolStripMenuItem.Text = "Update Reservation";
            // 
            // deleteReservationToolStripMenuItem
            // 
            deleteReservationToolStripMenuItem.Name = "deleteReservationToolStripMenuItem";
            deleteReservationToolStripMenuItem.Size = new Size(268, 34);
            deleteReservationToolStripMenuItem.Text = "Delete Reservation";
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.Size = new Size(265, 6);
            // 
            // backToolStripMenuItem2
            // 
            backToolStripMenuItem2.Name = "backToolStripMenuItem2";
            backToolStripMenuItem2.Size = new Size(268, 34);
            backToolStripMenuItem2.Text = "Back";
            // 
            // manageReservationDetailsToolStripMenuItem
            // 
            manageReservationDetailsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { insertDetailsToolStripMenuItem, viewDetailsToolStripMenuItem, updateDetailsToolStripMenuItem, deleteDetailsToolStripMenuItem });
            manageReservationDetailsToolStripMenuItem.Name = "manageReservationDetailsToolStripMenuItem";
            manageReservationDetailsToolStripMenuItem.Size = new Size(332, 34);
            manageReservationDetailsToolStripMenuItem.Text = "Manage Reservation Details";
            // 
            // insertDetailsToolStripMenuItem
            // 
            insertDetailsToolStripMenuItem.Name = "insertDetailsToolStripMenuItem";
            insertDetailsToolStripMenuItem.Size = new Size(230, 34);
            insertDetailsToolStripMenuItem.Text = "Insert Details";
            // 
            // viewDetailsToolStripMenuItem
            // 
            viewDetailsToolStripMenuItem.Name = "viewDetailsToolStripMenuItem";
            viewDetailsToolStripMenuItem.Size = new Size(230, 34);
            viewDetailsToolStripMenuItem.Text = "View Details";
            // 
            // updateDetailsToolStripMenuItem
            // 
            updateDetailsToolStripMenuItem.Name = "updateDetailsToolStripMenuItem";
            updateDetailsToolStripMenuItem.Size = new Size(230, 34);
            updateDetailsToolStripMenuItem.Text = "Update Details";
            // 
            // deleteDetailsToolStripMenuItem
            // 
            deleteDetailsToolStripMenuItem.Name = "deleteDetailsToolStripMenuItem";
            deleteDetailsToolStripMenuItem.Size = new Size(230, 34);
            deleteDetailsToolStripMenuItem.Text = "Delete Details";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(329, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(332, 34);
            exitToolStripMenuItem.Text = "Exit";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "FYAirLinesApp";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem eYAirLinesToolStripMenuItem;
        private ToolStripMenuItem manageFlightsToolStripMenuItem;
        private ToolStripMenuItem addFlightsToolStripMenuItem;
        private ToolStripMenuItem manageFlightScheduleToolStripMenuItem;
        private ToolStripMenuItem manageReservationToolStripMenuItem;
        private ToolStripMenuItem manageReservationDetailsToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem viewFlightsToolStripMenuItem;
        private ToolStripMenuItem updateFlightsToolStripMenuItem;
        private ToolStripMenuItem deleteFlightsToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem backToolStripMenuItem;
        private ToolStripMenuItem createScheduleToolStripMenuItem;
        private ToolStripMenuItem viewScheduleToolStripMenuItem;
        private ToolStripMenuItem updateScheduleToolStripMenuItem;
        private ToolStripMenuItem deleteScheduleToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem3;
        private ToolStripMenuItem backToolStripMenuItem1;
        private ToolStripMenuItem newReservationToolStripMenuItem;
        private ToolStripMenuItem viewReservationsToolStripMenuItem;
        private ToolStripMenuItem updateReservationToolStripMenuItem;
        private ToolStripMenuItem deleteReservationToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem4;
        private ToolStripMenuItem backToolStripMenuItem2;
        private ToolStripMenuItem insertDetailsToolStripMenuItem;
        private ToolStripMenuItem viewDetailsToolStripMenuItem;
        private ToolStripMenuItem updateDetailsToolStripMenuItem;
        private ToolStripMenuItem deleteDetailsToolStripMenuItem;
    }
}
