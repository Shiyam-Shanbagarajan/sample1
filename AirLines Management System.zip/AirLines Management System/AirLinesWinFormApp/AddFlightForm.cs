﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AirLinesLibrary;
using AirLinesLibrary.Models;
using AirLinesLibrary.Repos;

namespace AirLinesWinFormApp
{
    public partial class AddFlightForm : Form
    {
        public AddFlightForm()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Flight flight = new Flight();
            flight.FlightNo = txtfno.Text;
            flight.FromCity = txtfrom.Text;
            flight.ToCity = txtto.Text;
            flight.TotalSeats = Convert.ToInt32(txttot.Text);
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            flightrepo.InsertFlight(flight);
            MessageBox.Show("Flight Details Inserted");
            txtfno.Text = "";
            txtfrom.Text = "";
            txtto.Text = "";
            txttot.Text = "";
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                string fno = txtfno.Text;
                ADOFlightRepository flightrepo = new ADOFlightRepository();
                Flight flight = flightrepo.GetFlight(fno);
                txtfrom.Text = flight.FromCity;
                txtto.Text= flight.ToCity;
                txttot.Text = Convert.ToString(flight.TotalSeats);

            }
            catch (AirLineException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
