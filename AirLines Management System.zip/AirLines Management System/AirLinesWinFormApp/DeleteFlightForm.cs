﻿using AirLinesLibrary.Repos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AirLinesLibrary;

namespace AirLinesWinFormApp
{
    public partial class DeleteFlightForm : Form
    {
        public DeleteFlightForm()
        {
            InitializeComponent();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string fno = txtfno.Text;
            ADOFlightRepository flightrepo = new ADOFlightRepository();
            flightrepo.DeleteFlight(fno);
            MessageBox.Show("Flight Details Deleted");
        }
    }
}
