﻿namespace AirLinesWinFormApp
{
    partial class AddFlightForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtfno = new TextBox();
            txtfrom = new TextBox();
            txtto = new TextBox();
            txttot = new TextBox();
            btnadd = new Button();
            btnshow = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(87, 35);
            label1.Name = "label1";
            label1.Size = new Size(89, 25);
            label1.TabIndex = 0;
            label1.Text = "Flight No:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(87, 91);
            label2.Name = "label2";
            label2.Size = new Size(125, 25);
            label2.TabIndex = 1;
            label2.Text = "Departs From:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(87, 153);
            label3.Name = "label3";
            label3.Size = new Size(79, 25);
            label3.TabIndex = 2;
            label3.Text = "Goes To:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(87, 212);
            label4.Name = "label4";
            label4.Size = new Size(100, 25);
            label4.TabIndex = 3;
            label4.Text = "Total Seats:";
            // 
            // txtfno
            // 
            txtfno.Location = new Point(276, 29);
            txtfno.Name = "txtfno";
            txtfno.Size = new Size(135, 31);
            txtfno.TabIndex = 4;
            // 
            // txtfrom
            // 
            txtfrom.Location = new Point(276, 88);
            txtfrom.Name = "txtfrom";
            txtfrom.Size = new Size(135, 31);
            txtfrom.TabIndex = 5;
            // 
            // txtto
            // 
            txtto.Location = new Point(276, 147);
            txtto.Name = "txtto";
            txtto.Size = new Size(135, 31);
            txtto.TabIndex = 6;
            // 
            // txttot
            // 
            txttot.Location = new Point(276, 206);
            txttot.Name = "txttot";
            txttot.Size = new Size(135, 31);
            txttot.TabIndex = 7;
            // 
            // btnadd
            // 
            btnadd.Location = new Point(96, 303);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(121, 51);
            btnadd.TabIndex = 8;
            btnadd.Text = "Add";
            btnadd.UseVisualStyleBackColor = true;
            btnadd.Click += btnadd_Click;
            // 
            // btnshow
            // 
            btnshow.Location = new Point(264, 303);
            btnshow.Name = "btnshow";
            btnshow.Size = new Size(121, 51);
            btnshow.TabIndex = 9;
            btnshow.Text = "Show";
            btnshow.UseVisualStyleBackColor = true;
            btnshow.Click += btnshow_Click;
            // 
            // AddFlightForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnshow);
            Controls.Add(btnadd);
            Controls.Add(txttot);
            Controls.Add(txtto);
            Controls.Add(txtfrom);
            Controls.Add(txtfno);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddFlightForm";
            Text = "AddFlightForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtfno;
        private TextBox txtfrom;
        private TextBox txtto;
        private TextBox txttot;
        private Button btnadd;
        private Button btnshow;
    }
}