namespace AirLinesWinFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addFlightsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddFlightForm addFlightForm = new AddFlightForm();
            addFlightForm.MdiParent = this;
            addFlightForm.Show();
        }

        private void viewFlightsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAllFlightForm view = new ViewAllFlightForm();
            view.MdiParent = this;
            view.Show();
        }

        private void updateFlightsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateFlightForm update = new UpdateFlightForm();
            update.MdiParent = this;
            update.Show();
        }

        private void deleteFlightsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteFlightForm delete = new DeleteFlightForm();
            delete.MdiParent = this;
            delete.Show();
        }
    }
}
