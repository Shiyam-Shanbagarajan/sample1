﻿namespace AirLinesWinFormApp
{
    partial class DeleteFlightForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnshow = new Button();
            btndelete = new Button();
            txttot = new TextBox();
            txtto = new TextBox();
            txtfrom = new TextBox();
            txtfno = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnshow
            // 
            btnshow.Location = new Point(337, 330);
            btnshow.Name = "btnshow";
            btnshow.Size = new Size(117, 47);
            btnshow.TabIndex = 19;
            btnshow.Text = "Show";
            btnshow.UseVisualStyleBackColor = true;
            // 
            // btndelete
            // 
            btndelete.Location = new Point(146, 330);
            btndelete.Name = "btndelete";
            btndelete.Size = new Size(117, 47);
            btndelete.TabIndex = 18;
            btndelete.Text = "Delete";
            btndelete.UseVisualStyleBackColor = true;
            btndelete.Click += btndelete_Click;
            // 
            // txttot
            // 
            txttot.Location = new Point(298, 235);
            txttot.Name = "txttot";
            txttot.Size = new Size(138, 31);
            txttot.TabIndex = 17;
            // 
            // txtto
            // 
            txtto.Location = new Point(298, 158);
            txtto.Name = "txtto";
            txtto.Size = new Size(138, 31);
            txtto.TabIndex = 16;
            // 
            // txtfrom
            // 
            txtfrom.Location = new Point(298, 86);
            txtfrom.Name = "txtfrom";
            txtfrom.Size = new Size(138, 31);
            txtfrom.TabIndex = 15;
            // 
            // txtfno
            // 
            txtfno.Location = new Point(298, 22);
            txtfno.Name = "txtfno";
            txtfno.Size = new Size(138, 31);
            txtfno.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(122, 241);
            label4.Name = "label4";
            label4.Size = new Size(100, 25);
            label4.TabIndex = 13;
            label4.Text = "Total Seats:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(122, 164);
            label3.Name = "label3";
            label3.Size = new Size(34, 25);
            label3.TabIndex = 12;
            label3.Text = "To:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(122, 92);
            label2.Name = "label2";
            label2.Size = new Size(58, 25);
            label2.TabIndex = 11;
            label2.Text = "From:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(122, 28);
            label1.Name = "label1";
            label1.Size = new Size(89, 25);
            label1.TabIndex = 10;
            label1.Text = "Flight No:";
            // 
            // DeleteFlightForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnshow);
            Controls.Add(btndelete);
            Controls.Add(txttot);
            Controls.Add(txtto);
            Controls.Add(txtfrom);
            Controls.Add(txtfno);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "DeleteFlightForm";
            Text = "DeleteFlightForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnshow;
        private Button btndelete;
        private TextBox txttot;
        private TextBox txtto;
        private TextBox txtfrom;
        private TextBox txtfno;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}