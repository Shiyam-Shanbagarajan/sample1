﻿namespace AirLinesWinFormApp
{
    partial class ViewAllFlightForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flightGrid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)flightGrid).BeginInit();
            SuspendLayout();
            // 
            // flightGrid
            // 
            flightGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            flightGrid.Location = new Point(113, 56);
            flightGrid.Name = "flightGrid";
            flightGrid.RowHeadersWidth = 62;
            flightGrid.Size = new Size(498, 279);
            flightGrid.TabIndex = 0;
            // 
            // ViewAllFlightForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(flightGrid);
            Name = "ViewAllFlightForm";
            Text = "ViewAllFlightForm";
            Load += ViewAllFlightForm_Load;
            ((System.ComponentModel.ISupportInitialize)flightGrid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView flightGrid;
    }
}