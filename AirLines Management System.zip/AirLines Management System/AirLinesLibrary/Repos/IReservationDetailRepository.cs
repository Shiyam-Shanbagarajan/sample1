﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using AirLinesLibrary.Models;

namespace AirLinesLibrary.Repos
{
    public interface IReservationDetailRepository
    {
        void InsertDetail(ReservationDetail detail);
        void UpdateDetail(string pnr,int pno,ReservationDetail detail);
        void DeleteDetail(string pnr,int pno);
        List<ReservationDetail> GetAllDetails();
        ReservationDetail GetDetail(string pnr, int pno);
        List<ReservationDetail> GetDetailsByPNR(string pnr);


    }
}
