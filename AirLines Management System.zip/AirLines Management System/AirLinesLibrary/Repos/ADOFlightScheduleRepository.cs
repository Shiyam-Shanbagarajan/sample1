﻿using AirLinesLibrary.Models;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirLinesLibrary.Repos
{
    public class ADOFlightScheduleRepository : IFlightScheduleRepository
    {
        SqlConnection con;
        SqlCommand cmd;

        public ADOFlightScheduleRepository()
        {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; 
            database=EYAirLinesDB; integrated security=true ";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteSchedule(string fno, DateOnly flightDate)
        {
            cmd.CommandText = "DELETE FROM FlightSchedule WHERE FlightNo=@fno AND FlightDate=@fdate";
         
            cmd.Parameters.AddWithValue("@fno",fno);
            cmd.Parameters.AddWithValue("@fdate",flightDate);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<FlightSchedule> GetAllSchedules()
        {
            cmd.CommandText = "SELECT * FROM FlightSchedule";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<FlightSchedule> schedules = new List<FlightSchedule>();
            while (drdr.Read())
            {
                FlightSchedule schedule = new FlightSchedule();
                schedule.FlightNo = (string)drdr["FlightNo"];
                schedule.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                schedule.DepartTime = (DateTime)drdr["DepartTime"];
                schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                schedules.Add(schedule);
            }
            con.Close();
            return schedules;
        }

        public FlightSchedule GetSchedule(string fno, DateOnly flightDate)
        {
            cmd.CommandText = "SELECT * FROM FlightSchedule WHERE FlightNo=@fno AND FlightDate=@fdate";
            cmd.Parameters.AddWithValue("@fno", fno);
            cmd.Parameters.AddWithValue("@fdate", flightDate);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            
            if (drdr.HasRows)
            {
                drdr.Read();
                FlightSchedule schedule = new FlightSchedule();
                schedule.FlightNo = (string)drdr["FlightNo"];
                schedule.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                schedule.DepartTime = (DateTime)drdr["DepartTime"];
                schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                con.Close();
                return schedule;
            }
            else
            {
                con.Close();
                throw new AirLineException("No Flight is Scheduled on this Date.");
            }

        }

        public List<FlightSchedule> GetSchedulesByDate(DateOnly flightDate)
        {
            cmd.CommandText = "SELECT * FROM FlightSchedule  WHERE FlightDate=@fdate";
            
            cmd.Parameters.AddWithValue("@fdate", flightDate);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            
            if (drdr.HasRows)
            {
                List<FlightSchedule> schedules = new List<FlightSchedule> ();
                while(drdr.Read())
                {
                    FlightSchedule schedule = new FlightSchedule();
                    schedule.FlightNo = (string)drdr["FlightNo"];
                    schedule.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                    schedule.DepartTime = (DateTime)drdr["DepartTime"];
                    schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                    schedules.Add(schedule);
                }
                con.Close();
                return schedules;
            }
            else
            {
                con.Close();
                throw new AirLineException("No Flights are Scheduled on this Date.");
            }
        }

        public List<FlightSchedule> GetSchedulesByFlight(string fno)
        {
            cmd.CommandText = "SELECT * FROM FlightSchedule WHERE FlightNo=@fno";
            cmd.Parameters.AddWithValue("@fno", fno);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows)
            {
                List<FlightSchedule> schedules = new List<FlightSchedule>();
                while (drdr.Read())
                {
                    FlightSchedule schedule = new FlightSchedule();
                    schedule.FlightNo = (string)drdr["FlightNo"];
                    schedule.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                    schedule.DepartTime = (DateTime)drdr["DepartTime"];
                    schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                    schedules.Add (schedule);
                }
                con.Close();
                return schedules;
            }
            else
            {
                con.Close();
                throw new AirLineException("No Flights are Available.");
            }
        }

        public void InsertSchedule(FlightSchedule schedule)
        {
            cmd.CommandText = "INSERT INTO FlightSchedule VALUES(@fno,@fdate,@dptm,@artm)";
            
            cmd.Parameters.AddWithValue("@fno", schedule.FlightNo);
            cmd.Parameters.AddWithValue("@fdate", schedule.FlightDate);
            cmd.Parameters.AddWithValue("@dptm", schedule.DepartTime);
            cmd.Parameters.AddWithValue("@artm", schedule.ArriveTime);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void UpdateSchedule(string fno, DateOnly flightDate, FlightSchedule schedule)
        {
            cmd.CommandText = "@UPDATE FlightSchedule SET DepartTime = @DTIME, ArriveTime = @ATIME WHERE FlightNo = @FNO AND FlightDate = @FDATE";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", fno);
            cmd.Parameters.AddWithValue("@FDATE", flightDate);
            cmd.Parameters.AddWithValue("@DTIME", schedule.DepartTime);
            cmd.Parameters.AddWithValue("@ATIME", schedule.ArriveTime);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
