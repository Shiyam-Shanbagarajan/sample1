﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirLinesLibrary.Models;

namespace AirLinesLibrary.Repos
{
    public interface IFlightScheduleRepository
    {
        void InsertSchedule(FlightSchedule schedule);
        void UpdateSchedule(string fno, DateOnly flightDate ,FlightSchedule schedule);
        void DeleteSchedule(string fno, DateOnly flightDate);
        List<FlightSchedule> GetAllSchedules();
        FlightSchedule GetSchedule(string fno,DateOnly flightDate);
        List<FlightSchedule> GetSchedulesByFlight(string fno);
        List<FlightSchedule> GetSchedulesByDate(DateOnly flightDate);

    }
}
