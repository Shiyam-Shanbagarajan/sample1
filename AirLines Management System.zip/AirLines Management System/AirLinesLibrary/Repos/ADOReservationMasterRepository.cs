﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using AirLinesLibrary.Models;

namespace AirLinesLibrary.Repos
{
    public class ADOReservationMasterRepository : IReservationMasterRepository
    {
        SqlConnection con;
        SqlCommand cmd;

        public ADOReservationMasterRepository()
        {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; 
            database=EYAirLinesDB; integrated security=true ";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteMaster(string pnr)
        {
            cmd.CommandText = "DELETE FROM ReservationMaster WHERE PNR=@pnr";

            cmd.Parameters.AddWithValue("@pnr", pnr);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<ReservationMaster> GetAllMaster()
        {
            cmd.CommandText = "SELECT * FROM ReservationMaster";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<ReservationMaster> masters = new List<ReservationMaster>();
            while (drdr.Read())
            {
                ReservationMaster master = new ReservationMaster();
                master.PNR = (string)drdr["PNR"];
                master.FlightNo = (string)drdr["FlightNo"];
                master.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                masters.Add(master);
            }
            con.Close();
            return masters;

        }

        public ReservationMaster GetMaster(string pnr)
        {
            cmd.CommandText = "SELECT *  FROM ReservationMaster WHERE PNR=@pnr";
            cmd.Parameters.AddWithValue("@pnr", pnr);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows)
            {
                drdr.Read();
                ReservationMaster master = new ReservationMaster();
                master.PNR = (string)drdr["PNR"];
                master.FlightNo = (string)drdr["FlightNo"];
                master.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                con.Close();
                return master;
            }
            else
            {
                con.Close();
                throw new AirLineException("No such PNR");
            }
        }

        public List<ReservationMaster> GetMasterBySchedule(string fno, DateOnly fdate)
        {
            cmd.CommandText = "SELECT *  FROM ReservationMaster WHERE FlightNo=@fno AND FlightDate=@fdate";
            cmd.Parameters.AddWithValue("@fno", fno);
            cmd.Parameters.AddWithValue("@fdate", fdate);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<ReservationMaster> masters = new List<ReservationMaster>();
            if (drdr.HasRows)
            {
                while (drdr.Read())
                {
                    ReservationMaster master = new ReservationMaster();
                    master.PNR = (string)drdr["PNR"];
                    master.FlightNo = (string)drdr["FlightNo"];
                    master.FlightDate = DateOnly.FromDateTime((DateTime)drdr["FlightDate"]);
                    masters.Add(master);
                }
                con.Close();
                return masters;
            }
            else
            {
                con.Close();
                throw new AirLineException("No Reservations for this Schedule");
            }
        }
        public void InsertMaster(ReservationMaster master)
        {
            cmd.CommandText = "INSERT INTO ReservationMaster VALUES(@pnr,@fno,@fdate)";
            cmd.Parameters.AddWithValue("@pnr", master.PNR);
            cmd.Parameters.AddWithValue("@fno", master.FlightNo);
            cmd.Parameters.AddWithValue("@fdate", master.FlightDate);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateMaster(string pnr, ReservationMaster master)
        {
            cmd.CommandText = "UPDATE ReservationMaster SET FlightNo=@fno, FlightDate=@fdate WHERE PNR=@pnr";
            
            cmd.Parameters.AddWithValue("@fno",master.FlightNo);
            cmd.Parameters.AddWithValue("@fdate", master.FlightDate);
            cmd.Parameters.AddWithValue("@pnr",pnr);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
