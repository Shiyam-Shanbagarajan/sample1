﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirLinesLibrary.Models;

namespace AirLinesLibrary.Repos
{
    public interface IReservationMasterRepository
    {
        void InsertMaster(ReservationMaster master);
        void UpdateMaster(string pnr,ReservationMaster master);
        void DeleteMaster(string pnr);
        List<ReservationMaster> GetAllMaster();
        ReservationMaster GetMaster(string pnr);
        List<ReservationMaster> GetMasterBySchedule(string fno,DateOnly fdate);
    }
}
