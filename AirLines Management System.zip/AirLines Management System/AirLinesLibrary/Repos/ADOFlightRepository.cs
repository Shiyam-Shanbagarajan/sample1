﻿using AirLinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace AirLinesLibrary.Repos
{
    public class ADOFlightRepository : IFlightRepository
    {
        SqlConnection con;
        SqlCommand cmd;

        public ADOFlightRepository()
        {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; 
            database=EYAirLinesDB; integrated security=true ";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteFlight(string fno)
        {
            cmd.CommandText = "DELETE FROM Flight WHERE FlightNo='" + fno + "' ";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<Flight> GetAllFlights()
        {
            cmd.CommandText = "SELECT * FROM Flight";
            con.Open ();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<Flight> flights = new List<Flight>();
            while (drdr.Read())
            {
                Flight flight = new Flight();
                flight.FlightNo = (string)drdr["FlightNo"];
                flight.FromCity = (string)drdr["FromCity"];
                flight.ToCity = (string)drdr["ToCity"];
                flight.TotalSeats = (int)drdr["TotalSeats"];
                flights.Add(flight);
            }
            con.Close();
            return flights;
        }

    
        public Flight GetFlight(string fno)
        {
            cmd.CommandText = "SELECT * FROM Flight WHERE FlightNo='" + fno + "' ";
            con.Open ();
            SqlDataReader drdr = cmd.ExecuteReader();
            if(drdr.HasRows)
            {
                drdr.Read();
                Flight flight = new Flight();
                flight.FlightNo = (string)drdr["FlightNo"];
                flight.FromCity = (string)drdr["FromCity"];
                flight.ToCity = (string)drdr["ToCity"];
                flight.TotalSeats = (int)drdr["TotalSeats"];
                con.Close();
                return flight;
            }
            else
            {
                con.Close();
                throw new AirLineException("Invalid Flight Number");
            }
        }

        public void InsertFlight(Flight flight)
        {
            cmd.CommandText = "INSERT INTO Flight VALUES(@Fno,@Frct,@Toct,@Totst)";
            //con.Open ();
            cmd.Parameters.AddWithValue("@Fno", flight.FlightNo);
            cmd.Parameters.AddWithValue("@Frct", flight.FromCity);
            cmd.Parameters.AddWithValue("@Toct", flight.ToCity);
            cmd.Parameters.AddWithValue("@Totst", flight.TotalSeats);
            con.Open();
            cmd.ExecuteNonQuery ();
            con.Close();
        }

        public void UpdateFlight(string fno, Flight flight)
        {
            cmd.CommandText = "UPDATE Flight SET FromCity=@Frct, ToCity=@Toct, TotalSeats=@Totst WHERE FlightNo=@Fno";
            cmd.Parameters.AddWithValue("@Fno", fno);
            cmd.Parameters.AddWithValue("@Frct", flight.FromCity);
            cmd.Parameters.AddWithValue("@Toct", flight.ToCity);
            cmd.Parameters.AddWithValue("@Totst", flight.TotalSeats);
           
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
