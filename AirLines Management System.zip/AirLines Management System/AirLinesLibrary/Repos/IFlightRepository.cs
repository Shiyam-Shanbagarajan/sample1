﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirLinesLibrary.Models;

namespace AirLinesLibrary.Repos
{
    public interface IFlightRepository
    {
        void InsertFlight(Flight flight);
        void UpdateFlight(string fno,Flight flight);
        void DeleteFlight(string fno);
        List<Flight> GetAllFlights();
        Flight GetFlight(string fno);

    }
}
