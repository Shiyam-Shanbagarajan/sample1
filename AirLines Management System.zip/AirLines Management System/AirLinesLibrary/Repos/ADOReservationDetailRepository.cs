﻿using AirLinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace AirLinesLibrary.Repos
{
    public class ADOReservationDetailRepository : IReservationDetailRepository
    {
        SqlCommand cmd;
        SqlConnection con;

        public ADOReservationDetailRepository()
        {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; 
            database=EYAirLinesDB; integrated security=true ";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteDetail(string pnr, int pno)
        {
            cmd.CommandText = "DELETE FROM ReservationDetail WHERE PNR=@pnr AND PassengerNo=@pno";
            cmd.Parameters.AddWithValue("@pnr", pnr);
            cmd.Parameters.AddWithValue("@pno", pno);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public List<ReservationDetail> GetAllDetails()
        {
            cmd.CommandText = "SELECT * FROM ReservationDetail";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<ReservationDetail> details = new List<ReservationDetail>();
            while (drdr.Read())
            {
                ReservationDetail detail = new ReservationDetail();
                detail.PNR = (string)drdr["PNR"];
                detail.PassengerName = (string)drdr["PassengerName"];
                detail.PassengerNo = (int)drdr["PassengerNo"];
                detail.Gender = (string)drdr["Gender"];
                details.Add(detail);
            }
            con.Close();
            return details;
        }

        public ReservationDetail GetDetail(string pnr, int pno)
        {
            cmd.CommandText = "SELECT * FROM ReservationDetail WHERE PNR=@pnr AND PassengerNo=@pno";
            cmd.Parameters.AddWithValue("@pnr", pnr);
            cmd.Parameters.AddWithValue("@pno", pno);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if(drdr.HasRows)
            {
                drdr.Read();
                ReservationDetail detail = new ReservationDetail();
                detail.PNR = (string)drdr["PNR"];
                detail.PassengerName = (string)drdr["PassengerName"];
                detail.PassengerNo = (int)drdr["PassengerNo"];
                detail.Gender = (string)drdr["Gender"];
                con.Close();
                return detail;
            }
            else
            {
                con.Close() ;
                throw new AirLineException("No such Passenger or PNR");
            }

        }

        public List<ReservationDetail> GetDetailsByPNR(string pnr)
        {
            cmd.CommandText = "SELECT * FROM ReservationDetail WHERE PNR=@pnr";
            cmd.Parameters.AddWithValue("@pnr", pnr);
            con.Open();
            
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows)
            {
                List<ReservationDetail> details = new List<ReservationDetail>();   
                while (drdr.Read())
                {
                    ReservationDetail detail = new ReservationDetail();
                    detail.PNR = (string)drdr["PNR"];
                    detail.PassengerName = (string)drdr["PassengerName"];
                    detail.PassengerNo = (int)drdr["PassengerNo"];
                    detail.Gender = (string)drdr["Gender"];
                    details.Add(detail);
                }
                con.Close ();
                return details;
            }
            else
            {
                con.Close();
                throw new AirLineException("No such Passenger or PNR");
            }
        }

        public void InsertDetail(ReservationDetail detail)
        {
            cmd.CommandText = "INSERT INTO ReservationDetail VALUES(@Pnr,@pno,@pname,@gen)";
            cmd.Parameters.AddWithValue("@Pnr", detail.PNR);
            cmd.Parameters.AddWithValue("@pno", detail.PassengerNo);
            cmd.Parameters.AddWithValue("@pname", detail.PassengerName);
            cmd.Parameters.AddWithValue("@gen", detail.Gender);
            con.Open ();
            cmd.ExecuteNonQuery ();
            con.Close () ;
        }

        public void UpdateDetail(string pnr, int pno, ReservationDetail detail)
        {
            cmd.CommandText = "UPDATE ReservationDetail SET PassengerName=@pname, Gender=@gen WHERE PNR=@pnr AND PassengerNo=@pno";
            cmd.Parameters.AddWithValue("@pname", detail.PassengerName);
            cmd.Parameters.AddWithValue("@pno", pno);
            cmd.Parameters.AddWithValue("@pnr", pnr);
            cmd.Parameters.AddWithValue("@gen", detail.Gender);
            con.Open ();
            cmd.ExecuteNonQuery ();
            con.Close ();
        }
    }
}
