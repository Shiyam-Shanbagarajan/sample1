﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirLinesLibrary.Models
{
    public class ReservationMaster
    {
        public string PNR { get; set; }
        public string FlightNo { get; set; }
        public DateOnly FlightDate { get; set; }
    }
}
