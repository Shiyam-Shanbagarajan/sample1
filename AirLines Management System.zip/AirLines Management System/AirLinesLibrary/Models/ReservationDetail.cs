﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirLinesLibrary.Models
{
    public class ReservationDetail
    {
        public string PNR { get; set; }
        public int PassengerNo { get; set; }
        public string PassengerName { get; set; }
        public string Gender { get; set; }
    }
}
