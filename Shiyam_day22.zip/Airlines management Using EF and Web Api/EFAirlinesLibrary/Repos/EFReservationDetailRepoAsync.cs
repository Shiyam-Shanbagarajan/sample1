﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFReservationDetailRepoAsync:IReservationDetailRepoAsync
    {
        AirlinesDBGOContext ctx = new AirlinesDBGOContext();
        public async Task DeleteDetailAsync(string pnr, int pno)
        {
            ReservationDetail detail = await GetDetailAsync(pnr, pno);
            ctx.ReservationDetails.Remove(detail);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<ReservationDetail>> GetAllDetailsAsync()
        {
            List<ReservationDetail> details = await ctx.ReservationDetails.ToListAsync();
            return details;

        }

        public async Task<ReservationDetail> GetDetailAsync(string pnr, int pno)
        {
            try
            {
                ReservationDetail detail = await (from d in ctx.ReservationDetails where d.PNR == pnr && d.PassengerNo == pno select d).FirstAsync();
                return detail;
            }
            catch
            {
                throw new AirlinesException("Invalid details");
            }

        }

        public async Task<List<ReservationDetail>> GetDetailsByPNRAsync(string pnr)
        {
            List<ReservationDetail> details = await (from d in ctx.ReservationDetails where d.PNR == pnr select d).ToListAsync();
            if (details.Count > 0)
            {
                return details;
            }
            else
            {
                throw new AirlinesException("No such PNR");
            }

        }

        public async Task InsertDetailAsync(ReservationDetail detail)
        {
            await ctx.ReservationDetails.AddAsync(detail);
            await ctx.SaveChangesAsync();


        }

        public async Task UpdateDetailAsync(string pnr, int pno, ReservationDetail detail)
        {
            ReservationDetail det2edit = await GetDetailAsync(pnr, pno);
            det2edit.PassengerName = detail.PassengerName;
            det2edit.Gender = detail.Gender;
            det2edit.Age = detail.Age;
            await ctx.SaveChangesAsync();
        }
    }
}

