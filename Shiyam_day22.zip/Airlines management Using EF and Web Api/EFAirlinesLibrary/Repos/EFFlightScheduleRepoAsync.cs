﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFFlightScheduleRepoAsync:IFlightScheduleRepoAsync
    {
        AirlinesDBGOContext ctx = new AirlinesDBGOContext();
        public async Task DeleteScheduleAsync(string fno, DateOnly flightDate)
        {
            FlightSchedule schedule = await GetScheduleAsync(fno, flightDate);
            ctx.FlightSchedules.Remove(schedule);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<FlightSchedule>> GetAllSchedulesAsync()
        {
            List<FlightSchedule> schedules = await ctx.FlightSchedules.ToListAsync();
            return schedules;
        }

        public async Task<FlightSchedule> GetScheduleAsync(string fno, DateOnly flightDate)
        {
            try
            {
                FlightSchedule schedule = await (from fs in ctx.FlightSchedules where fs.FlightNo == fno && fs.FlightDate == flightDate select fs).FirstAsync();
                return schedule;
            }
            catch (Exception)
            {
                throw new AirlinesException("No such flight scheduled on this date");
            }
        }

        public async Task<List<FlightSchedule>> GetSchedulesByDateAsync(DateOnly flightDate)
        {
            List<FlightSchedule> schedules = await (from fs in ctx.FlightSchedules where fs.FlightDate == flightDate select fs).ToListAsync();
            if (schedules.Count > 0)
            {
                return schedules;
            }
            else
            {
                throw new AirlinesException("No flights scheduled on this date");
            }
        }

        public async Task<List<FlightSchedule>> GetSchedulesByFlightAsync(string fno)
        {
            List<FlightSchedule> schedules = await (from fs in ctx.FlightSchedules where fs.FlightNo == fno select fs).ToListAsync();
            if (schedules.Count > 0)
            {
                return schedules;
            }
            else
            {
                throw new AirlinesException("No such flight number");
            }
        }

        public async Task InsertScheduleAsync(FlightSchedule schedule)
        {
            await ctx.FlightSchedules.AddAsync(schedule);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateScheduleAsync(string fno, DateOnly flightDate, FlightSchedule schedule)
        {
            FlightSchedule schedule2edit = await GetScheduleAsync(fno, flightDate);
            schedule2edit.DepartTime = schedule.DepartTime;
            schedule2edit.ArriveTime = schedule.ArriveTime;
            await ctx.SaveChangesAsync();
        }
    }
}
