﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IReservationDetailRepoAsync
    {
        Task InsertDetailAsync(ReservationDetail detail);
        Task UpdateDetailAsync(string pnr, int pno, ReservationDetail detail);
        Task DeleteDetailAsync(string pnr, int pno);
        Task<List<ReservationDetail>> GetAllDetailsAsync();
        Task<ReservationDetail> GetDetailAsync(string pnr, int pno);
        Task<List<ReservationDetail>> GetDetailsByPNRAsync(string pnr);
    }
}
