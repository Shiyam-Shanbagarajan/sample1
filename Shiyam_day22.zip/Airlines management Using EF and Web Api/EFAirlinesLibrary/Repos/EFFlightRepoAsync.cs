﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFFlightRepoAsync:IFlightRepoAsync
    {
        AirlinesDBGOContext ctx = new AirlinesDBGOContext();

        public async Task DeleteFlightAsync(string fno)
        {
            Flight fl2del = await GetFlightAsync(fno);
            ctx.Flights.Remove(fl2del);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<Flight>> GetAllFlightsAsync()
        {
            List<Flight> flts = await ctx.Flights.ToListAsync();
            return flts;
        }

        public async Task<Flight> GetFlightAsync(string fno)
        {
            try
            {
                Flight flt = await (from f in ctx.Flights where f.FlightNo == fno select f).FirstAsync();
                return flt;
            }
            catch (Exception)
            {
                throw new AirlinesException("No such Flights");
            }
        }

        public async Task InsertFlightAsync(Flight flight)
        {
            await ctx.Flights.AddAsync(flight);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateFlightAsync(string fno, Flight flight)
        {
            Flight fl2edit = await GetFlightAsync(fno);
            fl2edit.FromCity = flight.FromCity;
            fl2edit.ToCity = flight.ToCity;
            fl2edit.TotalSeats = flight.TotalSeats;
            await ctx.SaveChangesAsync();
        }
        
    }
}
