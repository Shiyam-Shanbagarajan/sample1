﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IFlightScheduleRepoAsync
    {
        Task InsertScheduleAsync(FlightSchedule schedule);
        Task UpdateScheduleAsync(string fno, DateOnly flightDate, FlightSchedule schedule);
        Task DeleteScheduleAsync(string fno, DateOnly flightDate);
        Task<List<FlightSchedule>> GetAllSchedulesAsync();
        Task<FlightSchedule> GetScheduleAsync(string fno, DateOnly flightDate);
        Task<List<FlightSchedule>> GetSchedulesByFlightAsync(string fno);
        Task<List<FlightSchedule>> GetSchedulesByDateAsync(DateOnly flightDate);
    }
}
