﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IFlightRepoAsync
    {
        Task InsertFlightAsync(Flight flight);
        Task UpdateFlightAsync(string fno, Flight flight);
        Task DeleteFlightAsync(string fno);
        Task<List<Flight>> GetAllFlightsAsync();
        Task<Flight> GetFlightAsync(string fno);
    }
}
