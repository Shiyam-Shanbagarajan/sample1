﻿using EFAirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public interface IReservationMasterRepoAsync
    {
        Task InsertMasterAsync(ReservationMaster master);
        Task UpdateMasterAsync(string pnr, ReservationMaster master);
        Task DeleteMasterAsync(string pnr);
        Task<List<ReservationMaster>> GetAllMastersAsync();
        Task<ReservationMaster> GetMasterAsync(string pnr);
        Task<List<ReservationMaster>> GetMasterByScheduleAsync(string fno, DateOnly fdate);
    }
}
