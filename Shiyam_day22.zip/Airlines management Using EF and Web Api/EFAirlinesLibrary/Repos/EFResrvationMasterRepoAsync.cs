﻿using EFAirlinesLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Repos
{
    public class EFResrvationMasterRepoAsync : IReservationMasterRepoAsync
    {
        AirlinesDBGOContext ctx = new AirlinesDBGOContext();
        public async Task DeleteMasterAsync(string pnr)
        {
            ReservationMaster mast2del = await GetMasterAsync(pnr);
            ctx.ReservationMasters.Remove(mast2del);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<ReservationMaster>> GetAllMastersAsync()
        {
            List<ReservationMaster> masters = await ctx.ReservationMasters.ToListAsync();
            return masters;
        }

        public async Task<ReservationMaster> GetMasterAsync(string pnr)
        {
            try
            {
                ReservationMaster master = await (from m in ctx.ReservationMasters where m.PNR == pnr select m).FirstAsync();
                return master;
            }
            catch
            {
                throw new AirlinesException("No such PNR");
            }
        }

        public async Task<List<ReservationMaster>> GetMasterByScheduleAsync(string fno, DateOnly fdate)
        {
            List<ReservationMaster> masters = await (from m in ctx.ReservationMasters where m.FlightNo==fno && m.FlightDate==fdate select m).ToListAsync();
            if(masters.Count>0)
            {
                return masters;
            }
            else
            {
                throw new AirlinesException("No reservation with this flight");
            }
        }

        public async Task InsertMasterAsync(ReservationMaster master)
        {
            await ctx.ReservationMasters.AddAsync(master);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateMasterAsync(string pnr, ReservationMaster master)
        {
            ReservationMaster mast2edit = await GetMasterAsync(pnr);
            mast2edit.FlightNo = master.FlightNo;
            mast2edit.FlightDate = master.FlightDate;
            await ctx.SaveChangesAsync();
        }
    }
}
