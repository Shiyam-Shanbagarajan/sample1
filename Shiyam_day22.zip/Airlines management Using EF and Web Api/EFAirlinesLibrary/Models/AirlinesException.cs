﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFAirlinesLibrary.Models
{
    public class AirlinesException : Exception
    {
        public AirlinesException(string msg) : base(msg)
        {

        }
        public AirlinesException(string? message, Exception? innerException) : base(message, innerException)
        {

        }
    }
}
