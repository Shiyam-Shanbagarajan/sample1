﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFAirlinesLibrary.Models;

public partial class AirlinesDBGOContext : DbContext
{
    public AirlinesDBGOContext()
    {
    }

    public AirlinesDBGOContext(DbContextOptions<AirlinesDBGOContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Flight> Flights { get; set; }

    public virtual DbSet<FlightSchedule> FlightSchedules { get; set; }

    public virtual DbSet<ReservationDetail> ReservationDetails { get; set; }

    public virtual DbSet<ReservationMaster> ReservationMasters { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=AirlinesDBGO; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Flight>(entity =>
        {
            entity.HasKey(e => e.FlightNo).HasName("PK__Flight__8A9E3D457C25CDF5");

            entity.ToTable("Flight");

            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FromCity)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ToCity)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<FlightSchedule>(entity =>
        {
            entity.HasKey(e => new { e.FlightNo, e.FlightDate }).HasName("PK__FlightSc__BCFCC29DD3A3B32C");

            entity.ToTable("FlightSchedule");

            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.ArriveTime).HasColumnType("datetime");
            entity.Property(e => e.DepartTime).HasColumnType("datetime");

            entity.HasOne(d => d.FlightNoNavigation).WithMany(p => p.FlightSchedules)
                .HasForeignKey(d => d.FlightNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__FlightSch__Fligh__38996AB5");
        });

        modelBuilder.Entity<ReservationDetail>(entity =>
        {
            entity.HasKey(e => new { e.PNR, e.PassengerNo }).HasName("PK__Reservat__6DFE28AEFAF16CA1");

            entity.ToTable("ReservationDetail");

            entity.Property(e => e.PNR)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.PassengerName)
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.HasOne(d => d.PNRNavigation).WithMany(p => p.ReservationDetails)
                .HasForeignKey(d => d.PNR)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservation__PNR__3E52440B");
        });

        modelBuilder.Entity<ReservationMaster>(entity =>
        {
            entity.HasKey(e => e.PNR).HasName("PK__Reservat__C5773DD2E871CC25");

            entity.ToTable("ReservationMaster");

            entity.Property(e => e.PNR)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();

            entity.HasOne(d => d.FlightSchedule).WithMany(p => p.ReservationMasters)
                .HasForeignKey(d => new { d.FlightNo, d.FlightDate })
                .HasConstraintName("FK__ReservationMaste__3B75D760");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
