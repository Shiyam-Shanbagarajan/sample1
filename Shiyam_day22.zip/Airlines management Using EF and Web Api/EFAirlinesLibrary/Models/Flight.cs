﻿using System;
using System.Collections.Generic;

namespace EFAirlinesLibrary.Models;

public partial class Flight
{
    public string FlightNo { get; set; } = null!;

    public string FromCity { get; set; } = null!;

    public string ToCity { get; set; } = null!;

    public int? TotalSeats { get; set; }

    public virtual ICollection<FlightSchedule> FlightSchedules { get; set; } = new List<FlightSchedule>();
}
