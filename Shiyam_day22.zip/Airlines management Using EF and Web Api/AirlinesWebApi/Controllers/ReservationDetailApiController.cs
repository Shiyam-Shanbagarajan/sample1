﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;


namespace AirlinesWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationDetailApiController : ControllerBase
    {
        readonly IReservationDetailRepoAsync detailRepo;
        public ReservationDetailApiController(IReservationDetailRepoAsync detailRepoAsync)
        {
            detailRepo = detailRepoAsync;

        }
        [HttpGet]
        public async Task<ActionResult> GetAll()
        {
            List<ReservationDetail> details = await detailRepo.GetAllDetailsAsync();
            return Ok(details);
        }
        [HttpGet("{pnr}/{pno}")]
        public async Task<ActionResult> GetOne(string pnr, int pno)
        {
            try
            {
                ReservationDetail details = await detailRepo.GetDetailAsync(pnr, pno);
                return Ok(details);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("{pnr}")]
        public async Task<ActionResult> GetBypnr(string pnr)
        {
            try
            {
                List<ReservationDetail> details = await detailRepo.GetDetailsByPNRAsync(pnr);
                return Ok(details);

            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> Add(ReservationDetail detail)
        {
            try
            {

                await detailRepo.InsertDetailAsync(detail);
                return Created($"api/ReservationDetailApi/{detail.PNR}", detail);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPut("{pnr}/{pno}")]
        public async Task<ActionResult> Update(string pnr, int pno, ReservationDetail detail)
        {
            try
            {
                await detailRepo.UpdateDetailAsync(pnr, pno, detail);
                return Ok(detail);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }
        [HttpDelete("{pnr}/{pno}")]
        public async Task<ActionResult> Delete(string pnr, int pno)
        {
            try
            {
                await detailRepo.DeleteDetailAsync(pnr, pno);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}