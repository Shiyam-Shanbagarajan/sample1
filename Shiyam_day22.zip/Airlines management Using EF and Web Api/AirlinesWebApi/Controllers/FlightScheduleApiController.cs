﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary;
using EFAirlinesLibrary.Repos;
using EFAirlinesLibrary.Models;

namespace AirlinesWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightScheduleApiController : ControllerBase
    {
        readonly IFlightScheduleRepoAsync flightscheduleRepo;
        public FlightScheduleApiController(IFlightScheduleRepoAsync flightscheduleRepoAsync)
        {
            flightscheduleRepo = flightscheduleRepoAsync;
        }
        [HttpGet]
        public async Task<ActionResult> GetAllFlightSchedule()
        {
            List<FlightSchedule> schedules = await flightscheduleRepo.GetAllSchedulesAsync();
            return Ok(schedules);
        }
        [HttpGet("{fno}/{fdate}")]
        public async Task<ActionResult> GetOne(string fno, string fdate)
        {
            try
            {
                DateOnly flightDate = DateOnly.Parse(fdate);
                FlightSchedule schedule = await flightscheduleRepo.GetScheduleAsync(fno, flightDate);
                return Ok(schedule);
            }
            catch (AirlinesException ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("ByFno/{fno}")]
        public async Task<ActionResult> GetByFlight(string fno)
        {
            try
            {
                List<FlightSchedule> schedules = await flightscheduleRepo.GetSchedulesByFlightAsync(fno);
                return Ok(schedules);
            }
            catch (AirlinesException ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("ByFdate/{fdate}")]
        public async Task<ActionResult> GetByDate(string fdate)
        {
            try
            {
                DateOnly flightDate = DateOnly.Parse(fdate);
                List<FlightSchedule> schedules = await flightscheduleRepo.GetSchedulesByDateAsync(flightDate);
                return Ok(schedules);
            }
            catch (AirlinesException ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> InsertSchedule(FlightSchedule schedule)
        {
            try
            {
                await flightscheduleRepo.InsertScheduleAsync(schedule);
                return Created($"api/FlightScheduleApi/{schedule.FlightNo}/{schedule.FlightDate}", schedule);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{fno}/{fdate}")]
        public async Task<ActionResult> UpdateSchedule(string fno, string fdate, FlightSchedule schedule)
        {
            try
            {
                DateOnly flightDate = DateOnly.Parse(fdate);
                await flightscheduleRepo.UpdateScheduleAsync(fno, flightDate, schedule);
                return Ok(schedule);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{fno}/{fdate}")]
        public async Task<ActionResult> DeleteSchedule(string fno, string fdate)
        {
            try
            {
                DateOnly flightDate = DateOnly.Parse(fdate);
                await flightscheduleRepo.DeleteScheduleAsync(fno, flightDate);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}