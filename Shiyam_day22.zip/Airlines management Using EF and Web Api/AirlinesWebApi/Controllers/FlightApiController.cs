﻿using EFAirlinesLibrary.Repos;
using EFAirlinesLibrary.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AirlinesWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightApiController : ControllerBase
    {
        readonly IFlightRepoAsync flightRepo;
        public FlightApiController(IFlightRepoAsync flightRepoAsync)
        {
            flightRepo = flightRepoAsync;
        }
        [HttpGet]
        public async Task<ActionResult> GetAllflights()
        {
            List<Flight> flights = await flightRepo.GetAllFlightsAsync();
            return Ok(flights);
        }
        [HttpGet("{fno}")]
        public async Task<ActionResult> GetOne(string fno)
        {
            try
            {
                Flight flight = await flightRepo.GetFlightAsync(fno);
                return Ok(flight);
            }
            catch (AirlinesException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public async Task<ActionResult> Add(Flight flight)
        {
            try
            {

                await flightRepo.InsertFlightAsync(flight);
                return Created($"api/FlightApi/{flight.FlightNo}", flight);

            }
            catch (AirlinesException ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPut("{fno}")]
        public async Task<ActionResult> Update(string fno, Flight flight)
        {
            try
            {
                await flightRepo.UpdateFlightAsync(fno, flight);
                return Ok(flight);
            }
            catch (AirlinesException ex)
            {
                return BadRequest(ex.Message);

            }
        }
        [HttpDelete("{fno}")]
        public async Task<ActionResult> Delete(string fno)
        {
            try
            {
                await flightRepo.DeleteFlightAsync(fno);
                return Ok();
            }
            catch (AirlinesException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}