﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;

namespace AirlinesWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationMasterApiController : ControllerBase
    {
        readonly IReservationMasterRepoAsync masterRepo;
        public ReservationMasterApiController(IReservationMasterRepoAsync masterRepoAsync)
        {
            masterRepo = masterRepoAsync;
        }
        [HttpGet]
        public async Task<ActionResult> GetAllMasters()
        {
            List<ReservationMaster> masters = await masterRepo.GetAllMastersAsync();
            return Ok(masters);
        }
        [HttpGet("{pnr}")]
        public async Task<ActionResult> GetOneMaster(string pnr)
        {
            try
            {
                ReservationMaster master = await masterRepo.GetMasterAsync(pnr);
                return Ok(master);
            }
            catch(AirlinesException ex) 
            {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("{fno}/{fdate}")]
        public async Task<ActionResult> GetMasterBySchedule(string fno, String fdate)
        {
            try
            {
                DateOnly flightDate = DateOnly.Parse(fdate);
                List<ReservationMaster> masters = await masterRepo.GetMasterByScheduleAsync(fno, flightDate);
                return Ok(masters);
            }
            catch (AirlinesException ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> AddMaster(ReservationMaster master)
        {
            try
            {
                await masterRepo.InsertMasterAsync(master);
                return Created($"api/ReservationMasterApi/{master.PNR}", master);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{pnr}")]
        public async Task<ActionResult> UpdateMaster(string pnr, ReservationMaster master)
        {
            try
            {
                await masterRepo.UpdateMasterAsync(pnr, master);
                return Ok(master);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{pnr}")]
        public async Task<ActionResult> DeleteMaster(string pnr)
        {

            try
            {
                await masterRepo.DeleteMasterAsync(pnr);
                return Ok();
            }

            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}
