﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AirlinesMvcApp.Models;

namespace AirlinesMvcApp.Controllers
{
    public class FlightMvcController : Controller
    {
        static HttpClient client = new HttpClient() { BaseAddress = new Uri("http://localhost:5268/api/FlightApi/") };
        // GET: FlightMvcController
        public async Task<ActionResult> Index()
        {
            List<Flight> flights = await client.GetFromJsonAsync<List<Flight>>("");
            return View(flights);
        }

        // GET: FlightMvcController/Details/5
        public async Task<ActionResult> Details(string fno)
        {
            Flight flight = await client.GetFromJsonAsync<Flight>("" + fno);
            return View(flight);
        }

        // GET: FlightMvcController/Create
        public ActionResult Create()
        {
            Flight flight = new Flight();
            return View(flight);
        }

        // POST: FlightMvcController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Flight flight)
        {
            try
            {
                await client.PostAsJsonAsync<Flight>("",flight);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightMvcController/Edit/5
        [Route("Flight/Edit/{fno}")]
        public async Task<ActionResult> Edit(string fno)
        {
            Flight flight = await client.GetFromJsonAsync<Flight>("" + fno);
            return View(flight);
        }

        // POST: FlightMvcController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Flight/Edit/{fno}")]
        public async Task<ActionResult> Edit(string fno, Flight flight)
        {
            try
            {
                await client.PutAsJsonAsync<Flight>(""+fno, flight);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightMvcController/Delete/5
        [Route("Flight/Delete/{fno}")]
        public async Task<ActionResult> Delete(string fno)
        {
            Flight flight = await client.GetFromJsonAsync<Flight>("" + fno);
            return View(flight);
        }

        // POST: FlightMvcController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Flight/Delete/{fno}")]
        public async Task<ActionResult> Delete(string fno, IFormCollection collection)
        {
            try
            {
                await client.DeleteAsync(fno);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
