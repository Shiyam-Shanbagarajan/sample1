﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AirlinesMvcApp.Models;

namespace AirlinesMvcApp.Controllers
{
    public class FlightScheduleMvcController : Controller
    {
        static HttpClient client = new HttpClient() { BaseAddress = new Uri("http://localhost:5268/api/FlightScheduleApi/") };
        // GET: FlightScheduleMvcController
        public async Task<ActionResult> Index()
        {
            List<FlightSchedule> schedules = await client.GetFromJsonAsync<List<FlightSchedule>>("");
            return View(schedules);
        }

        // GET: FlightScheduleMvcController/Details/5
        public async Task<ActionResult> Details(string fno,string fdate)
        {
            FlightSchedule schedule = await client.GetFromJsonAsync<FlightSchedule>("" + fno + "/" + fdate);
            return View(schedule);
        }

        // GET: FlightScheduleMvcController/Create
        public ActionResult Create()
        {
            FlightSchedule schedule = new FlightSchedule();
            return View(schedule);
        }

        // POST: FlightScheduleMvcController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(FlightSchedule schedule)
        {
            try
            {
                await client.PostAsJsonAsync<FlightSchedule>("",schedule);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightScheduleMvcController/Edit/5
        [Route("FlightSchedule/Edit/{fno}/{fdate}")]
        public async Task<ActionResult> Edit(string fno,string fdate)
        {
            FlightSchedule schedule = await client.GetFromJsonAsync<FlightSchedule>("" + fno + "/" + fdate);
            return View(schedule);
        }

        // POST: FlightScheduleMvcController/Edit/5
        [Route("FlightSchedule/Edit/{fno}/{fdate}")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(string fno, string fdate, FlightSchedule schedule)
        {
            try
            {
                await client.PutAsJsonAsync<FlightSchedule>(""+fno+"/"+fdate,schedule);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FlightScheduleMvcController/Delete/5
        [Route("FlightSchedule/Delete/{fno}/{fdate}")]
        public async Task<ActionResult> Delete(string fno, string fdate)
        {
            FlightSchedule schedule = await client.GetFromJsonAsync<FlightSchedule>("" + fno + "/" + fdate);
            return View(schedule);
        }

        // POST: FlightScheduleMvcController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("FlightSchedule/Delete/{fno}/{fdate}")]
        public async Task<ActionResult> Delete(string fno, string fdate, IFormCollection collection)
        {
            try
            {
                await client.DeleteAsync(""+ fno + "/"+ fdate);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public async Task<ActionResult> ByFlightNo(string fno)
        {
            List<FlightSchedule> schedules = await client.GetFromJsonAsync<List<FlightSchedule>>("ByFno/" + fno);
            return View(schedules);
        }
        public async Task<ActionResult> ByFlightDate(string fdate)
        {
            List<FlightSchedule> schedules = await client.GetFromJsonAsync<List<FlightSchedule>>("ByFdate/" + fdate);
            return View(schedules);
        }
    }
}
