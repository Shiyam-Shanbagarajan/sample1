﻿using AirlinesMvcApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AirlinesMvcApp.Controllers
{
    public class ReservationMvcController : Controller
    {
        static HttpClient client = new HttpClient() { BaseAddress = new Uri("http://localhost:5268/api/ReservationMasterApi/") };
        static HttpClient client2 = new HttpClient() { BaseAddress = new Uri("http://localhost:5268/api/ReservationDetailApi/") };
        static int passengerCount;
        // GET: ReservationMvcController
        public async Task<ActionResult> Index()
        {
            List<ReservationMaster> reservations = await client.GetFromJsonAsync<List<ReservationMaster>>("");
            return View(reservations);
        }

        // GET: ReservationMvcController/Details/5
        public async Task<ActionResult> Details(string pnr)
        {
            ReservationMaster reservation = await client.GetFromJsonAsync<ReservationMaster>(""+pnr);
            return View(reservation);
        }

        // GET: ReservationMvcController/Create
        public ActionResult Create()
        {
            ReservationMaster reservation = new ReservationMaster();
            return View(reservation);
        }

        // POST: ReservationMvcController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(ReservationMaster reservation)
        {
            try
            {
                await client.PostAsJsonAsync<ReservationMaster>("", reservation);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReservationMvcController/Edit/5
        [Route("Reservation/Edit/{pnr}")]
        public async Task<ActionResult> Edit(string pnr)
        {

            ReservationMaster reservation = await client.GetFromJsonAsync<ReservationMaster>("" + pnr);
            return View(reservation);
        }

        // POST: ReservationMvcController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/Edit/{pnr}")]
        public async Task<ActionResult> Edit(string pnr, ReservationMaster reservation)
        {
            try
            {
                await client.PutAsJsonAsync<ReservationMaster>(""+pnr, reservation);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReservationMvcController/Delete/5
        [Route("Reservation/Delete/{pnr}")]
        public async Task<ActionResult> Delete(string pnr)
        {
            ReservationMaster reservation = await client.GetFromJsonAsync<ReservationMaster>("" + pnr);
            return View(reservation);
        }

        // POST: ReservationMvcController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/Delete/{pnr}")]
        public async Task<ActionResult> Delete(string pnr, IFormCollection collection)
        {
            try
            {
                await client.DeleteAsync(pnr);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public async Task<ActionResult> BySchedule(string fno, string fdate)
        {
            List<ReservationMaster> reservations = await client.GetFromJsonAsync<List<ReservationMaster>>("" + fno + "/" + fdate);
            return View(reservations);
        }
        public async Task<ActionResult> Passengers(string pnr)
        {
            List<ReservationDetail> passengers = await client2.GetFromJsonAsync<List<ReservationDetail>>("" + pnr);
            return View(passengers);
        }
        public async Task<ActionResult> PassengerDetails(string pnr, int pno)
        {
            ReservationDetail passenger = await client2.GetFromJsonAsync<ReservationDetail>("" + pnr + "/" + pno);
            
            return View(passenger);
        }
        public ActionResult CreatePassengers(string pnr)
        {
            ReservationDetail passenger = new ReservationDetail();
            passenger.PNR = pnr;
            passenger.PassengerNo = passengerCount + 1;
            return View(passenger);
        }

        // POST: ReservationMvcController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreatePassengers(ReservationDetail passenger)
        {
            try
            {
                await client2.PostAsJsonAsync<ReservationDetail>("", passenger);
                return RedirectToAction(nameof(Passengers), new {pnr = passenger.PNR});
            }
            catch
            {
                return View();
            }
        }
        [Route("Reservation/PassengerEdit/{pnr}/{pno}")]
        public async Task<ActionResult> PassengerEdit(string pnr,int pno)
        {

            ReservationDetail passenger = await client2.GetFromJsonAsync<ReservationDetail>("" + pnr + "/" + pno);
            return View(passenger);
        }

        // POST: ReservationMvcController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/PassengerEdit/{pnr}/{pno}")]
        public async Task<ActionResult> PassengerEdit(string pnr, int pno, ReservationDetail passenger)
        {
            try
            {
                await client2.PutAsJsonAsync<ReservationDetail>("" + pnr + "/" +pno, passenger);
                return RedirectToAction(nameof(Passengers), new { pnr = passenger.PNR });
            }
            catch
            {
                return View();
            }
        }

        // GET: ReservationMvcController/Delete/5
        [Route("Reservation/PassengerDelete/{pnr}/{pno}")]
        public async Task<ActionResult> PassengerDelete(string pnr, int pno)
        {
            ReservationDetail passenger = await client2.GetFromJsonAsync<ReservationDetail>("" + pnr + "/" + pno);
            return View(passenger);
        }

        // POST: ReservationMvcController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/PassengerDelete/{pnr}/{pno}")]
        public async Task<ActionResult> PassengerDelete(string pnr, int pno, IFormCollection collection)
        {
            try
            {
                await client2.DeleteAsync(""+pnr+"/"+pno);
                return RedirectToAction(nameof(Passengers), new {pnr=pnr});
            }
            catch
            {
                return View();
            }
        }
    }
}
