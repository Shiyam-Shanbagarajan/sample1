﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AsyncEFBankLibrary.Models;
using AsyncEFBankLibrary.Repos;

namespace BankWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankController : ControllerBase
    {
        readonly IBankRepoAsync bankRepo;
        public BankController(IBankRepoAsync bankRepoAsync)
        {
            bankRepo = bankRepoAsync;
        }
        [HttpGet]
        public async Task<ActionResult> GetAllAcounts()
        {
            List<SBAccount> accounts = await bankRepo.GetAllAccountsAsync();
            return Ok(accounts);
        }
        [HttpGet("{accno}")]
        public async Task<ActionResult> GetOneAccount(int accno)
        {
            try
            {
                SBAccount account = await bankRepo.GetAccountDetailsAsync(accno);
                return Ok(account);
            }
            catch(BankException ex)
            {
                return NotFound(ex.Message);
            }
        }
        [HttpGet("Transactions/{accno}")]
        public async Task<ActionResult> GetTransactions(int accno)
        {
            try
            {
                List<SBTransaction> transactions = await bankRepo.GetTransactionsAsync(accno);
                return Ok(transactions);
            }
            catch (BankException ex) 
            {
                return NotFound(ex.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> InsertAccount(SBAccount account)
        {
            try
            {
                await bankRepo.NewAccountAsync(account);
                return Created($"api/Bank/{account.AccountNumber}",account);
            }
            catch(Exception ex) 
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("Deposit/")]
        public async Task<ActionResult> DepositAmount(SBTransaction transaction)
        {
            try
            {
                await bankRepo.DepositAmountAsync((int)transaction.AccountNumber, (decimal)transaction.Amount);
                return Created($"api/Bank/Deposit/{transaction.AccountNumber}/{transaction.Amount}", transaction);


            }
            catch(BankException ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("WithDraw/")]
        public async Task<ActionResult> WithDrawAmount(SBTransaction transaction)
        {
            try
            {
                
                await bankRepo.WithdrawAmountAsync((int)transaction.AccountNumber, (decimal)transaction.Amount);
                return Created($"api/Bank/WithDraw/{transaction.AccountNumber}/{transaction.Amount}", transaction);


            }
            catch (BankException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
