﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BankMvcApp.Models;

namespace BankMvcApp.Controllers
{
    public class BankController : Controller
    {
        HttpClient client = new HttpClient() { BaseAddress = new Uri("http://localhost:5260/api/Bank/") };
        // GET: BankController
        public async Task<ActionResult> Index()
        {
            List<SBAccount> accounts = await client.GetFromJsonAsync<List<SBAccount>>("");
            return View(accounts);
        }

        // GET: BankController/Details/5
        public async Task<ActionResult> Details(int id)
        {
            SBAccount account = await client.GetFromJsonAsync<SBAccount>("" + id);
            return View(account);
        }

        // GET: BankController/Create
        public ActionResult Create()
        {
            SBAccount account = new SBAccount();
            return View(account);
        }

        // POST: BankController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(SBAccount account)
        {
            try
            {
                await client.PostAsJsonAsync<SBAccount>("",account);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BankController/Edit/5
        public ActionResult Deposit(int id)
        {
            SBTransaction transaction = new SBTransaction();
            transaction.AccountNumber = id;
            return View(transaction);
        }

        // POST: BankController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Deposit(SBTransaction transaction)
        {
            try
            {
                await client.PostAsJsonAsync<SBTransaction>("Deposit/",transaction);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BankController/Delete/5
        public async Task<ActionResult> WithDraw(int id)
        {
            SBTransaction transaction = new SBTransaction();
            transaction.AccountNumber = id;
            return View(transaction);
        }

        // POST: BankController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> WithDraw(SBTransaction transaction)
        {
            try
            {
                await client.PostAsJsonAsync<SBTransaction>("WithDraw/", transaction);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public async Task<ActionResult> Transaction(int id)
        {
            List<SBTransaction> transactions = await client.GetFromJsonAsync<List<SBTransaction>>("Transactions/" + id);
            return View(transactions);
        }
    }
}
