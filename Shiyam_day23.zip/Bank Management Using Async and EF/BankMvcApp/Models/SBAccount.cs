﻿namespace BankMvcApp.Models
{
    public class SBAccount
    {
        public int AccountNumber { get; set; }

        public string CustomerName { get; set; } = null!;

        public string? CustomerAddress { get; set; }

        public decimal? CurrentBalance { get; set; }
    }
}
