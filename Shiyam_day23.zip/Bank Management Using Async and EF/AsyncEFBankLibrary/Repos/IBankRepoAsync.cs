﻿using AsyncEFBankLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFBankLibrary.Repos
{
    public interface IBankRepoAsync
    {
        Task NewAccountAsync(SBAccount acc);
        Task<SBAccount> GetAccountDetailsAsync(int accno);
        Task<List<SBAccount>> GetAllAccountsAsync();
        Task DepositAmountAsync(int accno, decimal amt);
        Task WithdrawAmountAsync(int accno, decimal amt);
        Task<List<SBTransaction>> GetTransactionsAsync(int accno);
    }
}
