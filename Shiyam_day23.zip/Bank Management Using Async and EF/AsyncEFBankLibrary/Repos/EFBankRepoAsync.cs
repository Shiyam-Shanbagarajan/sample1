﻿using AsyncEFBankLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFBankLibrary.Repos
{
    public class EFBankRepoAsync : IBankRepoAsync
    {
        EYBankDBContext ctx = new EYBankDBContext();    
        public async Task DepositAmountAsync(int accno, decimal amt)
        {
            SBTransaction transaction = new SBTransaction();
            transaction.TransactionDate = DateTime.Now;
            transaction.Amount = amt;
            transaction.AccountNumber = accno;
            transaction.TransactionType = "D";
            await ctx.SBTransactions.AddAsync(transaction);
            SBAccount account = await GetAccountDetailsAsync(accno);
            account.CurrentBalance += amt;
            await ctx.SaveChangesAsync();
        }

        public async Task<SBAccount> GetAccountDetailsAsync(int accno)
        {
            try
            {
                SBAccount account =await  (from a in ctx.SBAccounts where a.AccountNumber == accno select a).FirstAsync();
                return account;
            }
            catch
            {
                throw new BankException("No such A/C #");
            }
        }

        public async Task<List<SBAccount>> GetAllAccountsAsync()
        {
            List<SBAccount> accounts = await ctx.SBAccounts.ToListAsync();
            return accounts;
        }

        public async Task<List<SBTransaction>> GetTransactionsAsync(int accno)
        {
            List<SBTransaction> transactions = await(from t in ctx.SBTransactions where t.AccountNumber==accno
                                                     select t).ToListAsync();
            if (transactions.Count > 0)
                return transactions;
            else
                throw new BankException("No transactions for this A/C#");
        }

        public async Task NewAccountAsync(SBAccount acc)
        {
            await ctx.SBAccounts.AddAsync(acc);
            await ctx.SaveChangesAsync();
        }

        public async Task WithdrawAmountAsync(int accno, decimal amt)
        {
            SBAccount account = await GetAccountDetailsAsync(accno);
            if (account.CurrentBalance >= amt)
            {
                SBTransaction transaction = new SBTransaction();
                transaction.TransactionDate = DateTime.Now;
                transaction.AccountNumber = accno;
                transaction.Amount = amt;
                transaction.TransactionType = "W";
                await ctx.SBTransactions.AddAsync(transaction);
                account.CurrentBalance -= amt;
                await ctx.SaveChangesAsync();
            }
            else
            {
                throw new BankException("Insufficient Balance");
            }
        }
    }
}
