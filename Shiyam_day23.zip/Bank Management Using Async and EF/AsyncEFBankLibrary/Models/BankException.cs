﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFBankLibrary.Models
{
    public class BankException : Exception
    {
        public BankException(string msg) : base(msg)
        {

        }
    }
}
