﻿using System;
using System.Collections.Generic;

namespace AsyncEFBankLibrary.Models;

public partial class SBAccount
{
    public int AccountNumber { get; set; }

    public string CustomerName { get; set; } = null!;

    public string? CustomerAddress { get; set; }

    public decimal? CurrentBalance { get; set; }

    public virtual ICollection<SBTransaction> SBTransactions { get; set; } = new List<SBTransaction>();
}
