﻿var products = [];
function Product(pid, pname, cat, price) {
    this.productId = pid;
    this.productName = pname;
    this.category = cat;
    this.price = price;
}
function addProduct(product) {
    products.push(product);
}
function getProduct(pid) {
    for (var i = 0; i < products.length; i++) {
        var product = products[i];
        if (product.productId == pid)
            return product;
    }
    throw "No such product id";
}
function getAllProducts() {
    return products;
}
function getProductsByCategory(cat) {
    var prods = [];
    for (var i = 0; i < products.length; i++) {
        product = products[i];
        if (product.category == cat)
            prods.push(product);
    }
    if (prods.length > 0)
        return prods;
    else
        throw "No such category";
}
function updateProduct(pid, product) {
    var prod2edit = getProduct(pid);
    prod2edit.productName = product.productName;
    prod2edit.category = product.category;
    prod2edit.price = product.price;
}
function deleteProduct(pid) {
    var prod2del = getProduct(pid);
    var pos = products.indexOf(prod2del);
    products.splice(pos, 1);
}
