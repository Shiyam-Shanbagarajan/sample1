﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AsyncEFInstituteLibrary.Models;

public partial class EYInstituteDBContext : DbContext
{
    public EYInstituteDBContext()
    {
    }

    public EYInstituteDBContext(DbContextOptions<EYInstituteDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Batch> Batches { get; set; }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=EYInstituteDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Batch>(entity =>
        {
            entity.HasKey(e => e.BatchCode).HasName("PK__Batch__B22ADA8F283AB2E0");

            entity.ToTable("Batch");

            entity.Property(e => e.BatchCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CourseCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.StartDate).HasColumnType("datetime");

            entity.HasOne(d => d.CourseCodeNavigation).WithMany(p => p.Batches)
                .HasForeignKey(d => d.CourseCode)
                .HasConstraintName("FK__Batch__CourseCod__398D8EEE");
        });

        modelBuilder.Entity<Course>(entity =>
        {
            entity.HasKey(e => e.CourseCode).HasName("PK__Course__FC00E0011BB4BDC9");

            entity.ToTable("Course");

            entity.Property(e => e.CourseCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CourseFee).HasColumnType("money");
            entity.Property(e => e.CourseTitle)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.RollNo).HasName("PK__Student__7886D5A0C7E2F719");

            entity.ToTable("Student");

            entity.Property(e => e.RollNo)
                .HasMaxLength(5)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.BatchCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.StudentAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.StudentName)
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.HasOne(d => d.BatchCodeNavigation).WithMany(p => p.Students)
                .HasForeignKey(d => d.BatchCode)
                .HasConstraintName("FK__Student__BatchCo__3C69FB99");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
