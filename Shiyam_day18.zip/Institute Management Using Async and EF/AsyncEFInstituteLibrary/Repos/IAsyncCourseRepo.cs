﻿using AsyncEFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public interface IAsyncCourseRepo
    {
        Task InsertCourseAsync(Course course);
        Task<Course> GetCourseAsync(string cc);
        Task<List<Course>> GetAllCoursesAsync();
        Task DeleteCourseAsync(string cc);
        Task UpdateCourseAsync(string cc,Course course);
    }
}
