﻿using AsyncEFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public interface IAsyncStudentRepo
    {
        Task InsertStudentAsync(Student student);
        Task<Student> GetStudentAsync(string rno);
        Task<List<Student>> GetAllStudentsAsync();
        Task<List<Student>> GetStudentsByBcAsync(string bc);
        Task UpdateStudentAsync(string rno,Student student);
        Task DeleteStudentAsync(string rno);
    }
}
