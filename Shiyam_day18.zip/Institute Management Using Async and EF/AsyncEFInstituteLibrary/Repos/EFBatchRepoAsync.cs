﻿using AsyncEFInstituteLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public class EFBatchRepoAsync : IAsyncBatchRepo
    {
        EYInstituteDBContext ctx = new EYInstituteDBContext();
        public async Task DeleteBatchAsync(string bc)
        {
            Batch batch2del = await GetBatchAsync(bc);
            ctx.Batches.Remove(batch2del);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<Batch>> GetAllBatchesAsync()
        {
            List<Batch> batches = await ctx.Batches.ToListAsync();
            return batches;
        }

        public async Task<Batch> GetBatchAsync(string bc)
        {
            try
            {
                Batch batch = await (from b in ctx.Batches where b.BatchCode == bc
                                     select b).FirstAsync();
                return batch;
            }
            catch
            {
                throw new Exception("No such batch code");
            }
        }

        public async Task<List<Batch>> GetBatchesByCcAsync(string cc)
        {
            List<Batch> batches = await(from b in ctx.Batches where b.CourseCode==cc
                                        select b).ToListAsync();
            if( batches.Count > 0 )
            {
                return batches;
            }
            else
            {
                throw new Exception("No batches for this course");
            }
        }

        public async Task InsertBatchAsync(Batch batch)
        {
            await ctx.Batches.AddAsync(batch);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateBatchAsync(string bc, Batch batch)
        {
            Batch batch2edit = await GetBatchAsync(bc);
            batch2edit.CourseCode = batch.CourseCode;   
            batch2edit.StartDate = batch.StartDate;
            batch2edit.EndDate = batch.EndDate;
            await ctx.SaveChangesAsync();
        }
    }
}
