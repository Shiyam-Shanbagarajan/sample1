﻿using AsyncEFInstituteLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public class EFCourseRepoAsync : IAsyncCourseRepo
    {
        EYInstituteDBContext ctx = new EYInstituteDBContext();
        public async Task DeleteCourseAsync(string cc)
        {
            Course courrse2del = await GetCourseAsync(cc);
            ctx.Courses.Remove(courrse2del);
            await ctx.SaveChangesAsync();
        }

        public async Task<List<Course>> GetAllCoursesAsync()
        {
            List<Course> courses = await ctx.Courses.ToListAsync();
            return courses;
        }

        public async Task<Course> GetCourseAsync(string cc)
        {
            try
            {
                Course course = await (from c in ctx.Courses where c.CourseCode == cc select c).FirstAsync();
                return course;
            }
            catch
            {
                throw new Exception("No such course code");
            }
        }

        public async Task InsertCourseAsync(Course course)
        {
            await ctx.Courses.AddAsync(course);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateCourseAsync(string cc, Course course)
        {
            Course course2edit = await GetCourseAsync(cc);
            course2edit.CourseTitle = course.CourseTitle;
            course2edit.Duration = course.Duration;
            course2edit.CourseFee = course.CourseFee;
            await ctx.SaveChangesAsync();
        }
    }
}
