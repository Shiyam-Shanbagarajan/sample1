﻿using AsyncEFInstituteLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public interface IAsyncBatchRepo
    {
        Task InsertBatchAsync(Batch batch);
        Task<Batch> GetBatchAsync(string bc);
        Task<List<Batch>> GetAllBatchesAsync();
        Task<List<Batch>> GetBatchesByCcAsync(string cc);
        Task UpdateBatchAsync(string bc,Batch batch);
        Task DeleteBatchAsync(string bc);
    }
}
