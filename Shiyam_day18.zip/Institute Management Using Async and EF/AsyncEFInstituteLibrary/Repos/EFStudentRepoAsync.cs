﻿using AsyncEFInstituteLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncEFInstituteLibrary.Repos
{
    public class EFStudentRepoAsync : IAsyncStudentRepo
    {
        EYInstituteDBContext ctx = new EYInstituteDBContext();
        public async Task DeleteStudentAsync(string rno)
        {
            Student student2del = await GetStudentAsync(rno);
            ctx.Students.Remove(student2del);   
            await ctx.SaveChangesAsync();
        }

        public async Task<List<Student>> GetAllStudentsAsync()
        {
            List<Student> students = await ctx.Students.ToListAsync();
            return students;
        }

        public async Task<Student> GetStudentAsync(string rno)
        {
            try
            {
                Student student = await (from s in ctx.Students where s.RollNo == rno
                                         select s).FirstAsync();
                return student;
            }
            catch
            {
                throw new Exception("No such roll number");
            }
        }

        public async Task<List<Student>> GetStudentsByBcAsync(string bc)
        {
            List<Student> students = await(from s in ctx.Students where s.BatchCode==bc
                                           select s).ToListAsync();
            if (students.Count > 0)
            {
                return students;
            }
            else
            {
                throw new Exception("No such student in this batch code");
            }
        }

        public async Task InsertStudentAsync(Student student)
        {
            await ctx.Students.AddAsync(student);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateStudentAsync(string rno, Student student)
        {
            Student student2edit = await  GetStudentAsync(rno);
            student2edit.BatchCode = student.BatchCode;
            student2edit.StudentName = student.StudentName;
            student2edit.StudentAddress = student.StudentAddress;   
            await ctx.SaveChangesAsync();
        }
    }
}
