﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AsyncEFInstituteLibrary.Models;
using AsyncEFInstituteLibrary.Repos;

namespace InstituteMvcApp.Controllers
{
    
    public class CourseController : Controller
    {
        //EFCourseRepoAsync repo = new EFCourseRepoAsync();
        IAsyncCourseRepo repo;
        public CourseController(IAsyncCourseRepo crsrepo)
        {
            repo = crsrepo;
        }
        // GET: CourseController
        public async Task<ActionResult> Index()
        {
            List<Course> courses = await repo.GetAllCoursesAsync();
            return View(courses);
        }

        // GET: CourseController/Details/5
        public async Task<ActionResult> Details(string cc)
        {
            Course course = await repo.GetCourseAsync(cc);
            return View(course);
        }

        // GET: CourseController/Create
        public async Task<ActionResult> Create()
        {
            Course course = new Course();
            return View(course);
        }

        // POST: CourseController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Course course)
        {
            try
            {
                await repo.InsertCourseAsync(course);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CourseController/Edit/5
        [Route("Course/Edit/{cc}")]
        public async Task<ActionResult> Edit(string cc)
        {
            Course course = await repo.GetCourseAsync(cc);
            return View(course);
        }

        // POST: CourseController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Edit/{cc}")]
        public async Task<ActionResult> Edit(string cc,Course course)
        {
            try
            {
                await repo.UpdateCourseAsync(cc, course);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CourseController/Delete/5
        [Route("Course/Delete/{cc}")]
        public async Task<ActionResult> Delete(string cc)
        {
            Course course = await repo.GetCourseAsync(cc);
            return View(course);
        }

        // POST: CourseController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Delete/{cc}")]
        public async Task<ActionResult> Delete(string cc, IFormCollection collection)
        {
            try
            {
                await repo.DeleteCourseAsync(cc);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
