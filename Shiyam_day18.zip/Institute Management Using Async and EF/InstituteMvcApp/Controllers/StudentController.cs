﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AsyncEFInstituteLibrary.Models;
using AsyncEFInstituteLibrary.Repos;

namespace InstituteMvcApp.Controllers
{
    public class StudentController : Controller
    {
        //EFStudentRepoAsync repo = new EFStudentRepoAsync();
        IAsyncStudentRepo repo;
        public StudentController(IAsyncStudentRepo studrepo)
        {
            repo = studrepo;
        }

        // GET: StudentController
        public async Task<ActionResult> Index()
        {
            List<Student> students = await repo.GetAllStudentsAsync();
            return View(students);
        }

        // GET: StudentController/Details/5
        public async Task<ActionResult> Details(string rno)
        {
            Student student = await repo.GetStudentAsync(rno);
            return View(student);
        }

        // GET: StudentController/Create
        public async Task<ActionResult> Create()
        {
            Student student = new Student();
            return View(student);
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Student student)
        {
            try
            {
                await repo.InsertStudentAsync(student);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Edit/5
        [Route("Student/Edit/{rno}")]
        public async Task<ActionResult> Edit(string rno)
        {
            Student student = await repo.GetStudentAsync(rno);
            return View(student);
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Edit/{rno}")]
        public async Task<ActionResult> Edit(string rno, Student student)
        {
            try
            {
                await repo.UpdateStudentAsync(rno, student);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Delete/5
        [Route("Student/Delete/{rno}")]
        public async Task<ActionResult> Delete(string rno)
        { 
            Student student = await repo.GetStudentAsync(rno);
            return View(student);
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Delete/{rno}")]
        public async Task<ActionResult> Delete(string rno, IFormCollection collection)
        {
            try
            {
                await repo.DeleteStudentAsync(rno);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public async Task<ActionResult> StudentByBatch(string bc)
        {
            List<Student> students = await repo.GetStudentsByBcAsync(bc);
            return View(students);
        }

    }
}
