﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AsyncEFInstituteLibrary.Models;
using AsyncEFInstituteLibrary.Repos;

namespace InstituteMvcApp.Controllers
{
    public class BatchController : Controller
    {
        //EFBatchRepoAsync repo = new EFBatchRepoAsync();
        IAsyncBatchRepo repo;
        public BatchController(IAsyncBatchRepo bchrepo)
        {
            repo = bchrepo;
        }
        // GET: BatchController
        public async Task<ActionResult> Index()
        {
            List<Batch> batches = await repo.GetAllBatchesAsync();
            return View(batches);
        }

        // GET: BatchController/Details/5
        public async Task<ActionResult> Details(string bc)
        {
            Batch batch = await repo.GetBatchAsync(bc);
            return View(batch);
        }

        // GET: BatchController/Create
        public async Task<ActionResult> Create()
        {
            Batch batch = new Batch();
            return View(batch);
        }

        // POST: BatchController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Batch batch)
        {
            try
            {
                await repo.InsertBatchAsync(batch);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BatchController/Edit/5
        [Route ("Batch/Edit/{bc}")]
        public async Task<ActionResult> Edit(string bc)
        {
            Batch batch = await repo.GetBatchAsync(bc);
            return View(batch);
        }

        // POST: BatchController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Edit/{bc}")]
        public async Task<ActionResult> Edit(string bc, Batch batch)
        {
            try
            {
                await repo.UpdateBatchAsync(bc,batch);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: BatchController/Delete/5
        [Route("Batch/Delete/{bc}")]
        public async Task<ActionResult> Delete(string bc)
        {
            Batch batch = await repo.GetBatchAsync(bc);
            return View(batch);
        }

        // POST: BatchController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Delete/{bc}")]
        public async Task<ActionResult> Delete(string bc, IFormCollection collection)
        {
            try
            {
                await repo.DeleteBatchAsync(bc);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public async Task<ActionResult> BatchByCc(string cc)
        {
            List<Batch> batches = await repo.GetBatchesByCcAsync(cc);
            return View(batches);
        }
    }
}
